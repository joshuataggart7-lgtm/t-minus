import { writeAudit } from "@/lib/audit";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { AppShell, LoadingNote, ErrorNote } from "@/components/app-shell";
import { DataTable, McPageHeader, StatusChip } from "@/components/ui-mc";
import { useRole } from "@/components/role-context";
import { supabase } from "@/integrations/supabase/client";
import { loadLaunchEvents, loadStateAuditRows } from "@/lib/launch-events";
import { deriveOverviewAcquisitionState } from "@/components/mission-control/operational-state";
import type { CenterOverrideRow } from "@/lib/center-config";
import type { RefData } from "@/lib/intake";
import type { AcqRow, PhasePlanRow, PollRow, ReviewRuleRow } from "@/lib/launch-sequence";
import { attachedKeys as keysFrom, savedDocKeys, withResolvedHolds } from "@/lib/hold";
import { computeMetrics, holdSince, type AcqMetrics, type MissionRow } from "@/lib/metrics";
import { agingItems, type CenterRow, type UserRow } from "@/lib/aging";
import { buildDigest, digestSections, digestAnnouncementBody, exportDigestPdf } from "@/lib/digest";
import { executiveBlocker } from "@/lib/executive-wording";

export const Route = createFileRoute("/digest")({
  head: () => ({
    meta: [
      { title: "Leadership digest · T-Minus" },
      {
        name: "description",
        content:
          "The week in one page: launched this week, at risk, aging holds, holds by reason by Center, and days returned to missions.",
      },
      { property: "og:title", content: "Leadership digest · T-Minus" },
      {
        property: "og:description",
        content: "A weekly digest computed from the record, exportable to PDF and postable as an announcement.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DigestPage,
});

function DigestPage() {
  const { authState, user, hasRole, readOnly } = useRole();
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const q = useQuery({
    queryKey: ["leadership-digest"],
    enabled: authState === "signed-in",
    queryFn: async () => {
      const [missions, acqs, plan, rules, overrides, thresholds, strategies, polls, log, centers, users, launches] = await Promise.all([
        supabase.from("missions").select("*").order("priority"),
        supabase.from("acquisition_facts").select("*").order("acquisition_id"),
        supabase.from("phase_plan").select("acquisition_type,phase,planned_days,order,note"),
        supabase.from("review_rules").select("*"),
        supabase.from("center_overrides").select("*"),
        supabase.from("thresholds").select("*"),
        supabase.from("enterprise_strategies").select("*"),
        supabase.from("polls").select("*"),
        loadStateAuditRows(),
        supabase.from("centers").select("center_code,center_name,aging_threshold_days"),
        supabase.from("users").select("name,role,title,center_code,supervisor_name,supervisor_email"),
        loadLaunchEvents(),
      ]);
      const attachments = await supabase.from("document_attachments").select("acquisition_id,doc_key");
      const [documents, templateRows] = await Promise.all([
        supabase.from("documents").select("acquisition_id,template_id"),
        supabase.from("templates").select("template_id,name"),
      ]);
      return {
        missions: (missions.data ?? []) as unknown as MissionRow[],
        acqs: (acqs.data ?? []) as unknown as AcqRow[],
        plan: (plan.data ?? []) as PhasePlanRow[],
        rules: (rules.data ?? []) as ReviewRuleRow[],
        overrides: overrides.data ?? [],
        thresholds: thresholds.data ?? [],
        strategies: strategies.data ?? [],
        polls: (polls.data ?? []) as PollRow[],
        attachments: attachments.data ?? [],
        documents: documents.data ?? [],
        templates: templateRows.data ?? [],
        stateLog: log,
        launches,
        centers: (centers.data ?? []) as unknown as CenterRow[],
        users: (users.data ?? []) as unknown as UserRow[],
      };
    },
  });

  const ref: RefData = useMemo(
    () => ({
      thresholds: (q.data?.thresholds ?? []).map((t) => ({
        name: t.name,
        value: t.value === null ? null : Number(t.value),
        citation: t.citation,
        note: t.note,
      })),
      overrides: (q.data?.overrides ?? []) as unknown as CenterOverrideRow[],
      phasePlan: (q.data?.plan ?? []).map((p) => ({
        acquisition_type: p.acquisition_type,
        phase: p.phase,
        planned_days: p.planned_days,
      })),
      strategies: (q.data?.strategies ?? []).map((s) => ({
        psl: s.psl,
        name: s.name,
        buying_location: s.buying_location,
        mandatory_vehicles: s.mandatory_vehicles,
        required_coordination: s.required_coordination,
      })),
    }),
    [q.data],
  );

  const metrics: AcqMetrics[] = useMemo(() => {
    if (!q.data) return [];
    return q.data.acqs.map((acq) => {
      const operational = deriveOverviewAcquisitionState(acq, [...q.data.stateLog, ...q.data.launches]);
      return computeMetrics(operational.acquisition, {
          attachedKeys: keysFrom(q.data.attachments ?? [], acq.acquisition_id),
        savedKeys: savedDocKeys(q.data.documents ?? [], q.data.templates ?? [], acq.acquisition_id),
        roster: q.data.users ?? [],
        plan: q.data.plan,
        rules: q.data.rules,
        polls: q.data.polls,
        ref,
        mission: q.data.missions.find((m) => m.mission_id === acq.mission_id) ?? null,
        holdSince: holdSince(acq, q.data.stateLog),
        awardDate: operational.actualAwardDate,
      });
    });
  }, [q.data, ref]);

  const digest = useMemo(() => {
    if (!q.data) return null;
    // Same hold reading as Escalations and the file page: recomputed cause and
    // owner first, a differing typed hold as "Also recorded".
    const resolved = withResolvedHolds(q.data.acqs, q.data.plan, q.data.attachments, q.data.documents, q.data.templates);
    const aging = agingItems(resolved, q.data.polls, q.data.centers, q.data.users);
    return buildDigest(metrics, aging);
  }, [q.data, metrics]);

  const sections = useMemo(() => (digest ? digestSections(digest) : []), [digest]);

  async function postAsAnnouncement() {
    if (!digest) return;
    setBusy(true);
    setMsg(null);
    const posted_at = new Date().toISOString();
    const title = `Leadership digest, week of ${digest.weekStart}`;
    const { error } = await supabase.from("announcements").insert({
      title,
      body: digestAnnouncementBody(digest),
      severity: "notice",
      audience_roles: null,
      audience_centers: null,
      effective_from: posted_at,
      effective_until: null,
      link: "/digest",
      requires_acknowledgment: false,
      posted_by: user.name,
      posted_at,
    });
    if (error) {
      setMsg(`The digest did not post: ${error.message}. Check that you are signed in as HQ, then send it again.`);
      setBusy(false);
      return;
    }
    await writeAudit({
      acquisition_id: null,
      actor: user.name,
      action: "Leadership digest sent",
      field: "announcement",
      old_value: null,
      new_value: title,
      reason: "Weekly digest",
      logged_at: posted_at,
    });
    setMsg("The digest is posted as an announcement.");
    setBusy(false);
  }

  return (
    <AppShell kit>
      <McPageHeader
        eyebrow="Oversight"
        title="Leadership digest"
        lead="The week in one page. Every figure is computed from the record; nothing here is typed by hand."
        actions={digest ? (
          <div className="mc-pa-actions">
            <button type="button" className="mc-req-button is-secondary" onClick={() => { if (!exportDigestPdf(digest)) setMsg("The print window did not open. Allow pop-ups for this site, then export again."); }}>Export as PDF</button>
            {hasRole("hq") && !readOnly ? (
              <button type="button" className="mc-req-button" onClick={() => void postAsAnnouncement()} disabled={busy}>{busy ? "Sending" : "Send as an announcement"}</button>
            ) : null}
          </div>
        ) : undefined}
      />

      {q.isLoading ? <LoadingNote what="the week's figures" /> : null}
      {q.error ? <ErrorNote message={`The digest could not load: ${(q.error as Error).message}. Reload the page.`} /> : null}

      {digest ? (
        <>
          <p className="text-[15px] leading-[22px] text-muted-foreground" data-numeric>
            Week of {digest.weekStart} through {digest.weekEnd}. Generated {new Date(digest.generatedAt).toLocaleString()}.{" "}
            <Link to="/" className="text-primary underline">Compare with the Acquisitions tab</Link>
          </p>
          {msg ? <p role="status" className="mt-3 max-w-[80ch] text-[15px]">{msg}</p> : null}

          <div className="mc-pa-stats is-4 mt-6">
            <div className="is-ontrack"><strong data-numeric>{digest.counts.running}</strong><span>Running</span></div>
            <div className={digest.counts.onHold ? "is-atrisk" : undefined}><strong data-numeric>{digest.counts.onHold}</strong><span>On hold</span></div>
            <div className="is-info"><strong data-numeric>{digest.counts.launchedThisQuarter}</strong><span>Launched this quarter</span></div>
            <div><strong data-numeric>{digest.counts.scrubbed}</strong><span>Scrubbed</span></div>
          </div>

          <section className="mc-kpanel mt-6">
            <div className="mc-kpanel-head"><div><h2 className="mc-kpanel-title">At risk: <span data-numeric>{digest.atRisk.length}</span></h2></div></div>
            <div className="mt-4">
              <DataTable label="Files at risk" empty={<p className="text-muted-foreground">No file is at risk this week.</p>}
                rowKey={(r) => r.id} rows={digest.atRisk.slice(0, 5)} columns={[
                  { key: "id", header: "File", rowHeader: true, cell: (r) => <Link to="/files/$acquisitionId" params={{ acquisitionId: r.id }}>{r.id}</Link> },
                  { key: "title", header: "Title", cell: (r) => r.title || "No title recorded" },
                  { key: "center", header: "Center", cell: (r) => r.center },
                  { key: "blocker", header: "Blocker", cell: (r) => executiveBlocker(r.blocker) },
                  { key: "owner", header: "Owner", cell: (r) => r.owner },
                  { key: "days", header: "Days to award", numeric: true, cell: (r) => <span data-numeric>{r.daysToAward === null ? "No date" : r.daysToAward}</span> },
                ]} />
            </div>
            {digest.atRisk.length > 5 ? <p className="mc-kpanel-foot" data-numeric>{digest.atRisk.length - 5} more at-risk files are in the full listing below.</p> : null}
          </section>

          <section className="mc-kpanel mt-6">
            <div className="mc-kpanel-head"><div><h2 className="mc-kpanel-title">Aging holds <span data-numeric>{digest.agingHolds.length}</span></h2></div></div>
            <div className="mt-4">
              <DataTable label="Aging holds" empty={<p className="text-muted-foreground">No hold has passed its Center window.</p>}
                rowKey={(r) => `${r.id}-${r.subject}`} rows={digest.agingHolds.slice(0, 5)} columns={[
                  { key: "id", header: "File", rowHeader: true, cell: (r) => <Link to="/files/$acquisitionId" params={{ acquisitionId: r.id }}>{r.id}</Link> },
                  { key: "center", header: "Center", cell: (r) => r.center },
                  { key: "subject", header: "Waiting on", cell: (r) => r.subject },
                  { key: "owner", header: "Owner", cell: (r) => r.owner },
                  { key: "age", header: "Age", numeric: true, cell: (r) => <span data-numeric>{r.ageDays} days</span> },
                  { key: "standing", header: "Standing", cell: (r) => <StatusChip tone="attention" label={`${r.ageDays - r.thresholdDays} days past the Center window`} /> },
                ]} />
            </div>
          </section>

          <details className="mc-kpanel mt-6">
            <summary className="mc-kpanel-title">The full digest, line by line</summary>
            <p className="mt-2 max-w-[80ch] text-[15px] leading-[22px] text-muted-foreground">The same lines the PDF and the announcement carry.</p>
            {sections.length === 0 ? <p className="mt-4 text-muted-foreground">Nothing has moved this week, so the digest has no lines to send.</p> : null}
            {sections.map((s) => (
              <section key={s.heading} className="mt-6">
                <h3 className="text-[18px] leading-6 font-medium">{s.heading}</h3>
                {s.lines.length === 0 ? <p className="mt-2 text-muted-foreground">Nothing recorded under this heading.</p> : (
                  <ul className="mt-2 max-w-[80ch] space-y-1 text-[15px] leading-[22px]">{s.lines.map((line) => <li key={line} data-numeric>{line}</li>)}</ul>
                )}
              </section>
            ))}
          </details>
        </>
      ) : null}
    </AppShell>
  );
}
