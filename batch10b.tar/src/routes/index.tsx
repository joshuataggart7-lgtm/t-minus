import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { pollOptions } from "@/lib/poll";
import { useEffect, useMemo, useRef, useState } from "react";
import { loadModTasks, modsByCenter } from "@/lib/clause-impact";
import { AppShell, LoadingNote, ErrorNote, EmptyState } from "@/components/app-shell";
import { DataTable, StatusChip } from "@/components/ui-mc";
import { executiveBlocker, recordedPaceLabel } from "@/lib/executive-wording";
import { countdownText, countdownView } from "@/components/launch-countdown";
import { useRole } from "@/components/role-context";
import { ExclusionsSweepPanel } from "@/components/exclusions-sweep-panel";
import { supabase } from "@/integrations/supabase/client";
import { loadLaunchEvents, launchedIdSet, loadStateAuditRows } from "@/lib/launch-events";
import type { CenterOverrideRow } from "@/lib/center-config";
import { daysBetween, todayISO, type RefData } from "@/lib/intake";
import type { AcqRow, PhasePlanRow, PollRow, ReviewRuleRow } from "@/lib/launch-sequence";
import {
  itemsFromRefs,
  itemsFromWatchRows,
  loadRegRefs,
  loadWatchRows,
  sortNewestFirst,
  withinDays,
} from "@/lib/watch";
import { SmallBusinessPanel } from "@/components/small-business-panel";
import {
  CentersTab,
  type CenterDocumentRow,
  type CenterTemplateRow,
} from "@/components/centers-tab";
import { successorRows } from "@/lib/successor";
import { agingItems, agingByCenter, type CenterRow, type UserRow } from "@/lib/aging";
import type { ThresholdRow } from "@/lib/small-business";
import { attachedKeys as keysFrom, savedDocKeys } from "@/lib/hold";
import {
  computeMetrics,
  formatDate,
  holdSince,
  missionDriver,
  type AcqMetrics,
  type MissionRow,
} from "@/lib/metrics";
import { PortfolioHero } from "@/components/mission-control/portfolio-hero";
import { derivePhaseEvidence } from "@/components/mission-control/gate-evidence";
import { DEFAULT_WATCH_WINDOW_DAYS, explainReadiness } from "@/components/mission-control/readiness";
import { docRowKey, docSatisfied, generatorKey } from "@/lib/launch-sequence";
import { buildReadinessContext } from "@/lib/readiness-context";
import { loadAttachmentKeyRows, loadDocumentKeyRows } from "@/lib/evidence-rows";
import { AttentionSeverityList } from "@/components/mission-control/attention-severity-list";
import { DaysReturned } from "@/components/mission-control/days-returned";
import { MissionMasthead } from "@/components/mission-control/mission-masthead";
import { deriveOverviewAcquisitionState } from "@/components/mission-control/operational-state";
import { isUnfavorableVote } from "@/lib/review-decisions";
import { auditActionLabel } from "@/lib/audit-display";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Executive Overview · T-Minus" },
      {
        name: "description",
        content:
          "T-Minus turns acquisition time into mission readiness: phase, next decision, days to award, and the blocker for every priority project.",
      },
      { property: "og:title", content: "Executive Overview · T-Minus" },
      {
        property: "og:description",
        content: "Mission readiness, next decision, and days to award for every priority project.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ExecutiveOverview,
});

export function ExecutiveOverview() {
  const { authState } = useRole();
  const [tab, setTab] = useState<"acquisitions" | "centers" | "enterprise">("acquisitions");

  const q = useQuery({
    queryKey: ["executive-overview"],
    enabled: authState === "signed-in",
    ...pollOptions,
    queryFn: async () => {
      const [
        missions,
        acqs,
        plan,
        rules,
        overrides,
        thresholds,
        strategies,
        polls,
        log,
        launches,
        stateLog,
        watchRows,
        refs,
      ] = await Promise.all([
        supabase.from("missions").select("*").order("priority"),
        supabase.from("acquisition_facts").select("*").order("acquisition_id"),
        supabase.from("phase_plan").select("acquisition_type,phase,planned_days,order,note"),
        supabase.from("review_rules").select("*"),
        supabase.from("center_overrides").select("*"),
        supabase.from("thresholds").select("*"),
        supabase.from("enterprise_strategies").select("*"),
        supabase.from("polls").select("*"),
        supabase
          .from("audit_log")
          .select("acquisition_id,action,actor,logged_at,phase")
          .order("logged_at", { ascending: false })
          .limit(500),
        loadLaunchEvents(),
        loadStateAuditRows(),
        loadWatchRows(),
        loadRegRefs(),
      ]);
      const [centers, users, documents, templateRows] = await Promise.all([
        supabase.from("centers").select("center_code,center_name,aging_threshold_days"),
        supabase
          .from("users")
          .select("name,role,title,center_code,supervisor_name,supervisor_email"),
        loadDocumentKeyRows(undefined, "acquisition_id,template_id,saved_at,version"),
        supabase.from("templates").select("template_id,name,hq_revision_date"),
      ]);
      const attachments = { data: await loadAttachmentKeyRows() };
      return {
        missions: (missions.data ?? []) as MissionRow[],
        acqs: (acqs.data ?? []) as unknown as AcqRow[],
        plan: (plan.data ?? []) as PhasePlanRow[],
        rules: (rules.data ?? []) as ReviewRuleRow[],
        overrides: overrides.data ?? [],
        thresholds: thresholds.data ?? [],
        strategies: strategies.data ?? [],
        polls: (polls.data ?? []) as PollRow[],
        centers: (centers.data ?? []) as unknown as CenterRow[],
        users: (users.data ?? []) as unknown as UserRow[],
        documents: documents as unknown as CenterDocumentRow[],
        templates: (templateRows.data ?? []) as unknown as CenterTemplateRow[],
        attachments: attachments.data ?? [],
        log: log.data ?? [],
        stateLog,
        launches,
        watch: sortNewestFirst([...itemsFromWatchRows(watchRows), ...itemsFromRefs(refs)]),
      };
    },
  });

  const ref: RefData = useMemo(
    () => ({
      thresholds: (q.data?.thresholds ?? []).map((t) => ({
        name: t.name,
        value: t.value === null ? null : Number(t.value),
        citation: t.citation,
        note: t.note,
      })),
      overrides: (q.data?.overrides ?? []) as unknown as CenterOverrideRow[],
      phasePlan: (q.data?.plan ?? []).map((p) => ({
        acquisition_type: p.acquisition_type,
        phase: p.phase,
        planned_days: p.planned_days,
      })),
      strategies: (q.data?.strategies ?? []).map((s) => ({
        psl: s.psl,
        name: s.name,
        buying_location: s.buying_location,
        mandatory_vehicles: s.mandatory_vehicles,
        required_coordination: s.required_coordination,
      })),
    }),
    [q.data],
  );

  const [watchWindowDays, setWatchWindowDays] = useState(DEFAULT_WATCH_WINDOW_DAYS);
  const metrics: AcqMetrics[] = useMemo(() => {
    if (!q.data) return [];
    const today = todayISO();
    return q.data.acqs.map((sourceAcq) => {
      const operational = deriveOverviewAcquisitionState(sourceAcq, [...q.data.stateLog, ...q.data.launches]);
      const acq = operational.acquisition;
      const attachedKeys = keysFrom(q.data.attachments ?? [], acq.acquisition_id);
      const savedKeys = savedDocKeys(q.data.documents ?? [], q.data.templates ?? [], acq.acquisition_id);
      const metric = computeMetrics(acq, {
        attachedKeys,
        savedKeys,
        roster: q.data.users ?? [],
        plan: q.data.plan,
        rules: q.data.rules,
        polls: q.data.polls,
        ref,
        mission: q.data.missions.find((m) => m.mission_id === acq.mission_id) ?? null,
        holdSince: holdSince(sourceAcq, q.data.stateLog),
        awardDate: operational.actualAwardDate,
      });
      // Official mark: phase-plan gate aging, real missing evidence, fixed 30-day window.
      const context = buildReadinessContext({ metric, acq, attachedKeys, savedKeys, today });
      const readiness = explainReadiness(metric, context);
      // What-if list only: same context with the slider's window. Never feeds tiles or counts.
      const whatIfReadiness =
        watchWindowDays === DEFAULT_WATCH_WINDOW_DAYS
          ? readiness
          : explainReadiness(metric, { ...context, watchWindowDays });
      const phaseEvidence = derivePhaseEvidence(metric, q.data.log, (d) =>
        d.field || generatorKey(d)
          ? docSatisfied(d, acq, attachedKeys ? attachedKeys.has(docRowKey(d)) : undefined, savedKeys)
          : null,
      );
      return { ...metric, readiness, whatIfReadiness, phaseEvidence };
    });
  }, [q.data, ref, watchWindowDays]);

  const missionRows = useMemo(() => {
    if (!q.data) return [];
    return [...q.data.missions]
      .sort((a, b) => (a.priority ?? 99) - (b.priority ?? 99))
      .map((mission) => ({
        mission,
        driver: missionDriver(metrics.filter((m) => m.acq.mission_id === mission.mission_id)),
      }))
      .filter((r) => r.driver) as { mission: MissionRow; driver: AcqMetrics }[];
  }, [q.data, metrics]);

  const latestEvents = useMemo(() => {
    const events: Record<string, { action: string; loggedAt: string }> = {};
    for (const row of q.data?.log ?? []) {
      const acquisitionId = String(row.acquisition_id ?? "");
      if (!acquisitionId || events[acquisitionId]) continue;
      events[acquisitionId] = {
        action: auditActionLabel(row.action == null ? null : String(row.action)) ?? "Activity recorded",
        loggedAt: String(row.logged_at ?? ""),
      };
    }
    return events;
  }, [q.data?.log]);

  // Stamped when this page loads, so a reader knows how fresh the figures are.
  const [computedAt, setComputedAt] = useState("");
  useEffect(() => {
    setComputedAt(
      new Date().toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }),
    );
  }, []);

  return (
    <AppShell wide overviewMode>
      <MissionMasthead />

      {q.isError ? (
        <ErrorNote message="The overview did not load. Refresh the page. If it still fails, tell the T-Minus team." />
      ) : null}

      <section aria-label="Mission clock" className="mb-8 w-full">
        <h2 className="sr-only">Mission clock</h2>
        {q.isLoading ? (
          <div className="mc-kpanel" role="status" aria-busy="true">
            <p className="mc-kpanel-title">Loading the priority projects</p>
            <p className="mt-2 text-[15px] leading-[22px] text-muted-foreground">The portfolio counts, the featured file and the attention list appear here once the record loads.</p>
          </div>
        ) : missionRows.length === 0 ? (
          <div className="mc-kpanel"><p className="text-muted-foreground">No priority projects are loaded yet.</p></div>
        ) : (
          <PortfolioHero
            metrics={metrics}
            missions={q.data?.missions ?? []}
            latestEvents={latestEvents}
            watchWindowDays={watchWindowDays}
            onWatchWindowChange={setWatchWindowDays}
          />
        )}
      </section>

      {/* The lower half waits for the same load as the hero, so the page never shows zeros under a loading line. */}
      {q.isLoading ? null : (
      <div className="mc-overview-environment">
        {computedAt ? (
          <div className="mc-refresh-line" data-numeric>
            <span className="mc-scan-pulse" aria-hidden="true" />
            Portfolio scan refreshed {computedAt}
          </div>
        ) : null}

        <div className="mc-light-ops-grid">
          <DaysReturned metrics={metrics} />
        </div>
        <AttentionSeverityList metrics={metrics} missions={q.data?.missions ?? []} />

        <div className="mc-watch-wrap">
          <WatchCard items={q.data?.watch ?? []} />
        </div>

        <div role="tablist" aria-label="Overview detail" className="mc-tabs">
          {(["acquisitions", "centers", "enterprise"] as const).map((t) => (
            <button
              key={t}
              type="button"
              role="tab"
              aria-selected={tab === t}
              onClick={() => setTab(t)}
              className={tab === t ? "mc-tab mc-tab-active" : "mc-tab"}
            >
              {t === "acquisitions" ? "Acquisitions" : t === "centers" ? "Centers" : "Enterprise"}
            </button>
          ))}
        </div>

        {tab === "acquisitions" ? (
          <ClockBoard
            metrics={metrics}
            plan={q.data?.plan ?? []}
            thresholds={ref.thresholds}
            polls={q.data?.polls ?? []}
            centers={q.data?.centers ?? []}
            users={q.data?.users ?? []}
            launchedIds={launchedIdSet(q.data?.launches ?? [])}
          />
        ) : tab === "centers" ? (
          <CentersTab
            metrics={metrics}
            polls={q.data?.polls ?? []}
            centers={q.data?.centers ?? []}
            users={q.data?.users ?? []}
            documents={q.data?.documents ?? []}
            templates={q.data?.templates ?? []}
          />
        ) : (
          <EnterpriseTab
            metrics={metrics}
            missionRows={missionRows}
            log={q.data?.log ?? []}
            polls={q.data?.polls ?? []}
            rules={q.data?.rules ?? []}
          />
        )}
      </div>
      )}
    </AppShell>
  );
}

function WatchCard({ items }: { items: ReturnType<typeof sortNewestFirst> }) {
  const recent = items.filter((i) => withinDays(i, 14));
  return (
    <section aria-label="Watch" className="mc-kpanel">
      <div className="mc-kpanel-head"><div><h2 className="mc-kpanel-title">Watch</h2></div></div>
      <p className="mt-3 text-[15px] leading-[22px]" data-numeric>
        {recent.length} new item{recent.length === 1 ? "" : "s"} in the last 14 days.{" "}
        <Link to="/watch" className="text-primary underline">Open Watch</Link>
      </p>
    </section>
  );
}

/** Aging holds and open reviews, counted by Center. */
function AgingPanel({
  acqs,
  polls,
  centers,
  users,
}: {
  acqs: AcqRow[];
  polls: PollRow[];
  centers: CenterRow[];
  users: UserRow[];
}) {
  const rows = useMemo(
    () => agingByCenter(agingItems(acqs, polls, centers, users)),
    [acqs, polls, centers, users],
  );
  const total = rows.reduce((n, r) => n + r.holds + r.polls, 0);

  return (
    <section className="mc-kpanel">
      <div className="mc-kpanel-head"><div>
        <h3 className="mc-kpanel-title">Aging holds and pending reviews</h3>
        <p className="mt-1 max-w-[70ch] text-[15px] leading-[22px] text-muted-foreground">A hold or an unanswered review request is aging once it passes the number of days the Center sets. Each aging item raises an entry in the digest for the owner's supervisor.</p>
      </div></div>
      <div className="mc-pa-stats"><div className={total ? "is-attention" : undefined}><strong data-numeric>{total}</strong><span>Aging items across all Centers</span></div></div>
      <div className="mt-4">
        <DataTable label="Aging holds and pending reviews by Center" empty={<p className="text-muted-foreground">Nothing is past its Center window.</p>}
          rowKey={(r) => r.centerCode} rows={rows} columns={[
            { key: "center", header: "Center", rowHeader: true, cell: (r) => r.centerCode },
            { key: "holds", header: "Aging holds", numeric: true, cell: (r) => <span data-numeric>{r.holds}</span> },
            { key: "polls", header: "Aging reviews", numeric: true, cell: (r) => <span data-numeric>{r.polls}</span> },
            { key: "days", header: "Aging after", numeric: true, cell: (r) => <span data-numeric>{r.thresholdDays} days</span> },
          ]} />
      </div>
      <p className="mc-kpanel-foot"><Link to="/escalations" className="text-primary underline">Open the escalation digest</Link></p>
    </section>
  );
}

/** Launched files and the date their replacement has to start. */
function SuccessorPanel({ acqs, plan }: { acqs: AcqRow[]; plan: PhasePlanRow[] }) {
  const rows = useMemo(() => successorRows(acqs, plan), [acqs, plan]);
  const flagged = rows.filter((r) => r.overdue);

  return (
    <section className="mc-kpanel">
      <div className="mc-kpanel-head"><div>
        <h3 className="mc-kpanel-title">Successor clock</h3>
        <p className="mt-1 max-w-[70ch] text-[15px] leading-[22px] text-muted-foreground">Method: the period of performance end date less the summed planned days in the phase plan for that acquisition type, plus a 30-day transition allowance. A file is flagged once that date has passed with no successor file linked to it. Advisory only: it never places a hold, and no successor file is created automatically.</p>
      </div></div>
      {rows.length === 0 ? (
        <p className="mt-4 text-muted-foreground">No launched file records a period of performance end.</p>
      ) : (
        <>
          <div className="mc-pa-stats"><div className={flagged.length ? "is-atrisk" : "is-ontrack"}><strong data-numeric>{flagged.length}</strong><span>Launched files past their successor start date with nothing linked</span></div></div>
          <div className="mt-4">
            <DataTable label="Successor clock files" rowKey={(r) => r.acq.acquisition_id} rows={rows} columns={[
              { key: "id", header: "Acquisition", rowHeader: true, cell: (r) => <Link to="/files/$acquisitionId" params={{ acquisitionId: r.acq.acquisition_id }}>{r.acq.acquisition_id}</Link> },
              { key: "end", header: "Period of performance ends", cell: (r) => <span data-numeric>{formatDate(String(r.acq.period_of_performance_end))}</span> },
              { key: "planned", header: "Planned days", numeric: true, cell: (r) => <span data-numeric>{`${r.plannedDays} + 30 transition`}</span> },
              { key: "start", header: "Successor must start by", cell: (r) => <span data-numeric>{formatDate(r.startBy)}</span> },
              { key: "succ", header: "Successor file", cell: (r) => r.successorId ? <Link to="/files/$acquisitionId" params={{ acquisitionId: r.successorId }}>{r.successorId}</Link> : "None linked" },
              { key: "standing", header: "Standing", cell: (r) => r.overdue ? <StatusChip tone="atrisk" label={`Successor overdue by ${Math.abs(r.daysUntilStart)} days`} /> : r.successorId ? <StatusChip tone="ontrack" label="Successor linked" /> : <StatusChip tone="ontrack" label={`Starts in ${r.daysUntilStart} days`} /> },
            ]} />
          </div>
        </>
      )}
    </section>
  );
}

function quarterStart(iso: string) {
  const d = new Date(iso + "T00:00:00Z");
  const q = Math.floor(d.getUTCMonth() / 3) * 3;
  return new Date(Date.UTC(d.getUTCFullYear(), q, 1)).toISOString().slice(0, 10);
}

function ClockBoard({
  metrics,
  plan,
  thresholds,
  polls,
  centers,
  users,
  launchedIds,
}: {
  metrics: AcqMetrics[];
  plan: PhasePlanRow[];
  thresholds: ThresholdRow[];
  polls: PollRow[];
  centers: CenterRow[];
  users: UserRow[];
  launchedIds: Set<string>;
}) {
  const today = todayISO();
  const qStart = quarterStart(today);

  const running = metrics.filter((m) => m.clockState === "running").length;
  const onHold = metrics.filter((m) => m.clockState === "hold");
  const launchedThisQuarterRows = metrics.filter(
    (m) =>
      m.clockState === "launched" &&
      m.awardDate &&
      m.awardDate >= qStart &&
      m.awardDate <= today,
  );
  const launchedThisQuarter = launchedThisQuarterRows.length;

  const scrubbed = metrics.filter((m) => m.clockState === "scrubbed").length;

  const modTasksQ = useQuery({ queryKey: ["clause-mod-tasks"], queryFn: loadModTasks });
  const modCounts = modsByCenter(modTasksQ.data ?? []);

  const byReason = useMemo(() => {
    const map = new Map<string, number>();
    for (const m of onHold) {
      const reason = m.hold?.reason ?? String(m.acq.hold_reason ?? "Reason not recorded");
      const key = reason.split("—")[0]!.trim();
      map.set(key, (map.get(key) ?? 0) + 1);
    }
    return [...map.entries()].sort((a, b) => b[1] - a[1]);
  }, [onHold]);

  const longestHolds = useMemo(
    () =>
      [...onHold]
        .map((m) => ({
          m,
          days: m.blockerSince ? Math.max(0, daysBetween(m.blockerSince, today)) : 0,
        }))
        .sort((a, b) => b.days - a.days)
        .slice(0, 10),
    [onHold, today],
  );

  const leadByPhase = useMemo(() => {
    const map = new Map<string, { completeN: number; completePlanned: number; completeActual: number; openN: number; openActual: number }>();
    for (const m of metrics) {
      for (const p of m.phases) {
        if (p.actual_days === null) continue;
        const row = map.get(p.phase) ?? { completeN: 0, completePlanned: 0, completeActual: 0, openN: 0, openActual: 0 };
        if (p.status === "complete") {
          row.completeN += 1;
          row.completePlanned += p.planned_days;
          row.completeActual += p.actual_days;
        } else {
          row.openN += 1;
          row.openActual += p.actual_days;
        }
        map.set(p.phase, row);
      }
    }
    const order = new Map(plan.map((p) => [p.phase ?? "", p.order ?? 0]));
    return [...map.entries()].sort((a, b) => (order.get(a[0]) ?? 0) - (order.get(b[0]) ?? 0));
  }, [metrics, plan]);

  const maxHold = Math.max(1, ...byReason.map(([, n]) => n));

  return (
    <div className="mc-pa-stack">
      <section className="mc-kpanel">
        <div className="mc-kpanel-head">
          <div>
            <h2 className="mc-kpanel-title">Acquisitions</h2>
            <p className="mt-1 text-[15px] leading-[22px] text-muted-foreground">Every number on this page is computed from the work itself.</p>
          </div>
        </div>
        <div className="mc-pa-stats is-4">
          <div><strong data-numeric>{running}</strong><span>Running</span></div>
          <div className={onHold.length ? "is-atrisk" : undefined}><strong data-numeric>{onHold.length}</strong><span>On hold</span></div>
          <div className="is-info"><strong data-numeric>{launchedThisQuarter}</strong><span>Launched this quarter</span></div>
          <div><strong data-numeric>{scrubbed}</strong><span>Scrubbed</span></div>
        </div>
      </section>

      <section className="mc-kpanel">
        <div className="mc-kpanel-head"><div>
          <h3 className="mc-kpanel-title">Clause change mods, done against due</h3>
          <p className="mt-1 text-[15px] leading-[22px] text-muted-foreground">Modifications required by a clause change, by Center. <Link to="/clause-changes" className="text-primary underline">Open the clause change impact list</Link>.</p>
        </div></div>
        <div className="mt-4">
          {modCounts.length === 0 ? (
            <p className="text-muted-foreground">No clause change mod task has been created.</p>
          ) : (
            <DataTable label="Clause change mods by Center" rowKey={(c) => c.center} rows={modCounts} columns={[
              { key: "center", header: "Center", cell: (c) => c.center, rowHeader: true },
              { key: "done", header: "Done", numeric: true, cell: (c) => <span data-numeric>{c.done}</span> },
              { key: "due", header: "Due", numeric: true, cell: (c) => <span data-numeric>{c.due}</span> },
            ]} />
          )}
        </div>
      </section>

      <section className="mc-kpanel">
        <div className="mc-kpanel-head"><div><h3 className="mc-kpanel-title">Holds by reason</h3></div></div>
        {byReason.length === 0 ? (
          <p className="mt-4 text-muted-foreground">Nothing is on hold.</p>
        ) : (
          <ul className="mt-4 max-w-[70ch] space-y-3">
            {byReason.map(([reason, n]) => (
              <li key={reason} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
                <div className="min-w-0">
                  <p className="text-[15px] leading-[22px]">{executiveBlocker(reason)}</p>
                  <div className="mt-1 h-2 rounded" style={{ width: `${(n / maxHold) * 100}%`, backgroundColor: "var(--atrisk)" }} role="img" aria-label={`${n} on hold for ${reason}`} />
                </div>
                <span className="text-[15px]" data-numeric>{n}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="mc-kpanel">
        <div className="mc-kpanel-head"><div><h3 className="mc-kpanel-title">The ten longest current holds</h3></div></div>
        <div className="mt-4">
          <DataTable label="The ten longest current holds" empty={<p className="text-muted-foreground">No file is on hold today.</p>}
            rowKey={({ m }) => m.acq.acquisition_id} rows={longestHolds} columns={[
              { key: "id", header: "Acquisition", rowHeader: true, cell: ({ m }) => <Link to="/files/$acquisitionId" params={{ acquisitionId: m.acq.acquisition_id }}>{m.acq.acquisition_id}</Link> },
              { key: "reason", header: "Reason", cell: ({ m }) => executiveBlocker(m.hold?.reason ?? String(m.acq.hold_reason ?? "Not recorded")) },
              { key: "owner", header: "Responsible role", cell: ({ m }) => m.blockerOwner ?? String(m.acq.hold_owner ?? "Not recorded") },
              ...(longestHolds.some(({ m }) => m.blockerSince) ? [{ key: "days", header: "Days on hold", numeric: true, cell: ({ m, days }: { m: AcqMetrics; days: number }) => <span data-numeric>{days}</span> }] : []),
            ]} />
          {longestHolds.length && !longestHolds.some(({ m }) => m.blockerSince) ? (
            <p className="mc-kpanel-foot mt-3 text-[15px] leading-[22px] text-muted-foreground">The day each hold started is not on the record, so days on hold are not shown.</p>
          ) : null}
        </div>
      </section>

      <section className="mc-kpanel">
        <div className="mc-kpanel-head"><div><h3 className="mc-kpanel-title">Lead time by phase against the phase plan</h3></div></div>
        <div className="mt-4">
          <DataTable label="Lead time by phase against the phase plan" empty={<p className="text-muted-foreground">No phase has recorded time yet.</p>}
            rowKey={([phase]) => phase} rows={leadByPhase} columns={[
              { key: "phase", header: "Phase", rowHeader: true, cell: ([phase]) => phase },
              { key: "n", header: "Files measured", numeric: true, cell: ([, r]) => <span data-numeric>{r.completeN + r.openN}</span> },
              { key: "reading", header: "What the days measure", cell: ([, r]) => recordedPaceLabel(r) },
            ]} />
        </div>
      </section>

      <AgingPanel acqs={metrics.map((m) => m.acq)} polls={polls} centers={centers} users={users} />
      <SuccessorPanel acqs={metrics.map((m) => m.acq)} plan={plan} />

      <SmallBusinessPanel acqs={metrics.map((m) => m.acq)} thresholds={thresholds} launchedIds={launchedIds} />

      <ExclusionsSweepPanel />
    </div>
  );
}

function EnterpriseTab({
  metrics,
  missionRows,
  log,
  polls,
  rules,
}: {
  metrics: AcqMetrics[];
  missionRows: { mission: MissionRow; driver: AcqMetrics }[];
  log: { acquisition_id: string | null; action: string | null; logged_at: string | null }[];
  polls: PollRow[];
  rules: ReviewRuleRow[];
}) {
  const frame = useRef<HTMLIFrameElement | null>(null);
  const [ready, setReady] = useState(false);

  const payload = useMemo(() => {
    const citation = (role: string) =>
      rules.find((r) => r.reviewer_role.toLowerCase() === role.toLowerCase())?.citation ?? null;
    return {
      summary: {
        running: metrics.filter((m) => m.clockState === "running").length,
        hold: metrics.filter((m) => m.clockState === "hold").length,
        launched: metrics.filter((m) => m.clockState === "launched").length,
        pending_votes: polls.filter((p) => (p.vote ?? "pending") === "pending").length,
        nogo_votes: polls.filter((p) => isUnfavorableVote(p.vote)).length,
        audit_entries: log.length,
      },
      projects: missionRows.map(({ mission, driver }) => ({
        mission: mission.name,
        acquisition_id: driver.acq.acquisition_id,
        title: String(driver.acq.title ?? ""),
        phase: driver.currentPhase,
        next_decision: driver.nextDecision,
        days_to_award: driver.daysToAward,
        status: driver.status,
      })),
      acquisitions: metrics.map((m) => ({
        acquisition_id: m.acq.acquisition_id,
        title: String(m.acq.title ?? ""),
        center_code: String(m.acq.center_code ?? ""),
        phase: m.currentPhase,
        blocker: m.blocker,
        blocker_owner: m.blockerOwner,
        days_to_award: m.daysToAward,
        status: m.status,
      })),
      recurring: polls.map((p) => ({
        acquisition_id: p.acquisition_id,
        phase: p.phase,
        reviewer_role: p.reviewer_role ?? "",
        reviewer_name: p.reviewer_name ?? "Not yet assigned",
        due_date: p.due_date,
        vote: p.vote ?? "pending",
        citation: citation(p.reviewer_role ?? ""),
      })),
    };
  }, [metrics, missionRows, log, polls, rules]);

  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      if (e.data?.type === "tminus:ready") setReady(true);
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  useEffect(() => {
    if (!ready) return;
    frame.current?.contentWindow?.postMessage({ type: "tminus:live", payload }, "*");
  }, [ready, payload]);

  const sample = metrics.find((m) => m.acq.acquisition_id === "A-2027-0101");

  return (
    <div>
      <h2 className="text-[18px] leading-6 font-medium">Enterprise</h2>
      <p className="mt-1 max-w-[80ch] text-muted-foreground">
        A prototype view with fictional data. Its workforce tabs are unchanged. Executive
        summary, project status, and recurring actions read live from T-Minus.
      </p>

      <section className="mc-kpanel mt-6">
        <div className="mc-kpanel-head">
          <div>
            <h3 className="mc-kpanel-title">Microsoft Teams bot</h3>
            <p className="mt-1 max-w-[80ch] text-[15px] leading-[22px] text-muted-foreground">
              A production Teams bot so mission leaders ask T-Minus in the flow of work. Mention the
              bot with a PR number and it answers with the file&apos;s clock line, status, owner,
              and a link to the file. It reads the same data as the Executive Overview; nothing is
              stored in Teams.
            </p>
          </div>
          <StatusChip tone="neutral" label="Planned" />
        </div>

        <div className="mt-4 rounded-lg border border-border bg-canvas p-4">
          <p className="text-[13px] font-medium text-muted-foreground">Mock transcript</p>
          <div className="mt-3 space-y-3 text-[13px] leading-5">
            <p className="text-foreground">
              <span className="font-medium">You</span>
              <br />
              @T-Minus where is PR 4200999101
            </p>
            <p className="text-foreground">
              <span className="font-medium">T-Minus</span>
              <br />
              PR 4200999101 is A-2027-0101, {sample?.acq.title ??
                "Commercial Aviation Services"}. Center {sample?.acq.center_code ?? "ARC"}, owner{" "}
              {String(
                (sample?.acq as Record<string, unknown> | undefined)?.["co_name"] ?? "",
              ).trim() || "not recorded"}
              .
              {sample ? (
                <>
                  {" "}
                  Status: {sample.status}. Phase: {sample.currentPhaseLabel ?? sample.currentPhase}.{" "}
                  {countdownText(countdownView(sample))}.
                  {sample.blocker ? ` Blocker: ${sample.blocker}.` : ""}
                </>
              ) : (
                <> Status: On Track. Phase: Market Research.</>
              )}{" "}
              Open the file: /files/A-2027-0101.
            </p>
          </div>
          <p className="mt-3 text-[12px] text-muted-foreground">
            Sample uses fictional acquisition A-2027-0101. The production bot would answer for any
            PR the caller can see under the same role-based access.
          </p>
        </div>
      </section>

      <iframe
        ref={frame}
        title="Enterprise prototype"
        src="/orbit-prototype.html"
        className="mt-6 h-[1200px] w-full rounded-lg border border-border bg-background"
      />
    </div>
  );
}
