import { writeAudit } from "@/lib/audit";
import { phaseAlias, storedPhaseNames } from "@/lib/phase-alias";
import { DECISION_LABEL, REVIEW_KIND_LABEL, decisionAudit, decisionOptions, decisionOutcome, type ReviewDecision } from "@/lib/review-decisions";
import { ReviewDecisionFields, rationaleMissing } from "@/components/review-decision-fields";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { pollOptions } from "@/lib/poll";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useRef, useState } from "react";
import { AppShell, PageHeader, StatusMark, LoadingNote, ErrorNote, EmptyState } from "@/components/app-shell";
import { useRole } from "@/components/role-context";
import { useCanWrite } from "@/lib/use-can-write";
import { DEMO_READ_ONLY_NOTE, failureText, isDemoSession } from "@/lib/demo-guard";
import { RegulationSidebar } from "@/components/regulation-sidebar";
import { DefectReport } from "@/components/defect-report";
import { TableScrollRegion } from "@/components/table-scroll-region";
import { ShareDocument } from "@/components/share-document";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { loadFileAuditHistory, loadStateAuditRows } from "@/lib/launch-events";
import {
  fileAsOfficialFinal,
  unfileOfficialFinal,
  isOfficialFinal,
  officialMeta,
  FILE_IT_LABEL,
  FILE_IT_NOTE,
} from "@/lib/official-file";
import { samContractAwards, type ComparablesView } from "@/lib/sam-contract-awards.functions";
import { draftJofocItem, DRAFTABLE_JOFOC_FIELDS, type DraftProvenance } from "@/lib/ai-draft.functions";
import {
  checkoutTime,
  claimCheckout,
  loadCheckout,
  releaseCheckout,
  type Checkout,
  takeOverCheckout,
} from "@/lib/document-checkout";
import {
  itemsFromRefs,
  itemsFromWatchRows,
  loadRegRefs,
  loadWatchRows,
  newerGuidance,
} from "@/lib/watch";
import { daysBetween, formatMoney, todayISO, type RefData } from "@/lib/intake";
import { ANTICIPATED_AWARD_TBD, ANTICIPATED_AWARD_TBD_NOTE } from "@/lib/forecast";
import { attachedKeys as keysFrom, savedDocKeys } from "@/lib/hold";
import { computeMetrics, holdSince } from "@/lib/metrics";
import { countdownText } from "@/components/launch-countdown";
import { deriveOverviewAcquisitionState, overviewCountdownView } from "@/components/mission-control/operational-state";
import { explainWorkReadiness } from "@/components/mission-control/readiness";
import { MissionNavigator, MissionNavSection, type MissionNavItem } from "@/components/mission-control/mission-navigator";
import { WorkShellHeader, WorkShellLayout, type SaveState } from "@/components/mission-control/work-surface-shell";
import {
  buildSequence,
  phaseForTemplate,
  pollBoard,
  type PhasePlanRow,
  type AcqRow,
  type PollRow,
  type ReviewRuleRow,
} from "@/lib/launch-sequence";
import { CITE_HEADING_ONLY_NOTE, citeStatus, useCiteCorpus } from "@/lib/cite-stub";
import { signedInName } from "@/lib/account-name";
import { recordReadReceiptQuietly } from "@/lib/read-receipts";
import { DocReadCount } from "@/components/doc-read-count";
import {
  exportDocx,
  exportPdf,
  money,
  prefill,
  renderDocument,
  templateByKey,
  badgeCitation,
  badgeNote,
  validate,
  sectionCitation,
  sectionStandingText,
  MFR_KEY,
  MFR_SITUATION_PURPOSE,
  type SectionDef,
  visibleFields,
  visibleSections,
  type ThresholdRow,
  type Values,
  technicalRepresentative,
  approvingOfficialTitle,
  matchAuthorityOption,
} from "@/lib/template-engine";
import { generateJofocDocx } from "@/lib/jofoc-docx";
import { generateJofocUrgencyDocx, isUrgencyJofocPath } from "@/lib/jofoc-urgency-docx";
import { generateJofoc8aDocx, isJofoc8aPath } from "@/lib/jofoc-8a-docx";
import { generateLsjDocx } from "@/lib/lsj-docx";
import { generatePpmDocx, isPpmPath } from "@/lib/ppm-docx";
import {
  generateSetAsidePreawardDocx,
  isSetAsidePreawardPath,
} from "@/lib/setaside-preaward-docx";
import { generateDrfpCoverDocx, isDrfpCoverPath } from "@/lib/drfp-cover-docx";
import {
  generateOptionJustificationDocx,
  isOptionJustificationPath,
} from "@/lib/option-justification-docx";
import {
  generateOptionExerciseDocx,
  isOptionExercisePath,
} from "@/lib/option-exercise-docx";
import { generateFoeBrandDocx, isFoeBrandPath } from "@/lib/foe-brand-docx";
import { generateUcaJustDocx, isUcaJustPath } from "@/lib/uca-just-docx";
import { BLACKOUT_UNAVAILABLE, generateBlackoutDocx, isBlackoutPath } from "@/lib/blackout-docx";
import { isSoftWalkCommercialSample } from "@/lib/softwalk-samples";
import {
  generatePostawardSuccessDocx,
  generatePostawardUnsuccessDocx,
  generatePostawardSuccessCompanionDocx,
  generatePostawardUnsuccessCompanionDocx,
  isPart15NotificationPath,
  simplifiedNoticeCitation,
  unsuccessfulExplanationCitation,
} from "@/lib/postaward-letters-docx";

import { downloadDocxBytes } from "@/lib/rfp-cover-docx";
import { applyMemoDraft, draftMemoBody, draftedKeys, jofocAuthorityDefault, jofocNoticeStatus, mfrPurposeLabel, samNoticeAuthority, repairSavedSamResponseRule, type PacketClauseLine, type ResearchLogLine } from "@/lib/memo-draft";
import { selectPacketClauses, type ClauseRow } from "@/lib/clause-packet";
import { isSupersededAttachmentKey, retiredNote, tabRank } from "@/lib/file-index";
import { ShowTheText, useCitationTextState } from "@/components/show-the-text";
import { Nova } from "@/components/nova";
import type { FindingMap } from "@/lib/research-findings";
import {
  buildMemoDoc,
  buildMemoHeader,
  exportMemoDocx,
  exportMemoPdf,
  memoDefaultFor,
  type MemoHeader,
  type MemoRoutingRow,
} from "@/lib/nf1858";
import { dayWord } from "@/lib/pluralize";
import { AdvisoryTag } from "@/components/advisory-tag";
import { DetailsList, DetailsSection, WithDetailsPanel } from "@/components/ui-mc";

export const Route = createFileRoute("/documents/$templateKey/$acquisitionId")({
  // An unsuccessful-offeror letter can be opened straight onto one quoter on
  // the evaluation record: /documents/postaward-letter-unsuccessful/ID?offeror=2
  // standalone=1 marks a draft taken outside the launch sequence; situation=1
  // opens the memorandum for record on the unexpected-event scaffold.
  validateSearch: (search: Record<string, unknown>): { offeror?: number; standalone?: 1; situation?: 1 } => {
    const raw = Number(String(search["offeror"] ?? "").replace(/\D+/g, ""));
    const out: { offeror?: number; standalone?: 1; situation?: 1 } = {};
    if (raw >= 1 && raw <= 4) out.offeror = raw;
    if (String(search["standalone"] ?? "") === "1") out.standalone = 1;
    if (String(search["situation"] ?? "") === "1") out.situation = 1;
    return out;
  },
  head: () => ({
    meta: [
      { title: "Document · T-Minus" },
      {
        name: "description",
        content: "A versioned template filled from the acquisition record, with its citation and tier.",
      },
      { property: "og:title", content: "Document · T-Minus" },
      {
        property: "og:description",
        content: "A versioned template filled from the acquisition record, with its citation and tier.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  errorComponent: () => (
    <AppShell>
      <PageHeader title="This document could not be loaded" lead="Go back to Templates and open it again." />
    </AppShell>
  ),
  notFoundComponent: () => (
    <AppShell>
      <PageHeader title="Document not found" lead="Go back to Templates and choose a live template." />
    </AppShell>
  ),
  component: DocumentPage,
});

/** The comparables paragraph, written only from what the check returned. */
function comparablesSummary(view: ComparablesView): string {
  const stamp = view.checkedAt ? ` Checked ${new Date(view.checkedAt).toLocaleString("en-US")}.` : "";
  if (!view.awards.length) {
    return [
      `The comparables check ran for NAICS ${view.naicsCode} and PSC ${view.pscCode} and returned no prior awards.${stamp}`,
      view.providerNote ?? "",
      "No comparable award is assumed here. State the basis relied on instead.",
    ]
      .filter(Boolean)
      .join("\n");
  }
  const lines = view.awards.map(
    (a) => `${a.agency} · ${a.awardDate} · ${a.pricingType} · ${a.extentCompeted} · ${money(a.obligatedAmount)}`,
  );
  const lead =
    view.source === "local"
      ? `Comparables are drawn from T-Minus prior actions: live feed unavailable. ${view.awards.length} prior action${view.awards.length === 1 ? "" : "s"} on NAICS ${view.naicsCode} / PSC ${view.pscCode} in this system, not external awards.${stamp}`
      : `${view.awards.length} prior award${view.awards.length === 1 ? "" : "s"} for NAICS ${view.naicsCode} and PSC ${view.pscCode} between ${money(view.minValue)} and ${money(view.maxValue)} (${view.sourceLabel}).${stamp}`;
  return [lead, ...lines].join("\n");
}

/** Plain-language summary of the answers stored on the intake record. */
function answersSummary(answers: unknown): string {
  if (!answers || typeof answers !== "object") return "";
  const entries = Object.entries(answers as Record<string, unknown>).filter(
    ([, v]) => v !== null && v !== "" && v !== false,
  );
  if (!entries.length) return "";
  return entries.map(([k, v]) => `${k}: ${typeof v === "boolean" ? "Yes" : String(v)}`).join("\n");
}

// The draft flag belongs beside a field as a chip, never inside the text the
// officer reads or signs. These two helpers keep the wording out of the body
// while remembering which fields carried it.
const DRAFT_MARK =
  /\s*(?:Drafted from the record[,—-]?\s*confirm\.?|Draft[,—-]?\s*confirm\.?)\s*/gi;

function markedKeys(values: Values): string[] {
  return Object.entries(values)
    .filter(([, v]) => typeof v === "string" && new RegExp(DRAFT_MARK.source, "i").test(v))
    .map(([k]) => k);
}

function stripDraftMarks(values: Values): Values {
  const out: Values = { ...values };
  for (const [k, v] of Object.entries(out)) {
    if (typeof v !== "string") continue;
    const cleaned = v.replace(DRAFT_MARK, " ").replace(/[ \t]{2,}/g, " ").trim();
    if (cleaned !== v) out[k] = cleaned;
  }
  return out;
}

function DocumentPage() {
  const { templateKey, acquisitionId } = Route.useParams();
  const search = Route.useSearch() as { offeror?: number; standalone?: 1; situation?: 1 };
  const { authState, hasRole, hasAnyRole, user, readOnly } = useRole();
  const queryClient = useQueryClient();
  const citeCorpus = useCiteCorpus();
  const def = templateByKey(templateKey);
  const canWrite = useCanWrite();

  // A read receipt for this visit. Soft tracking: it never blocks the document,
  // a phase or a hold, and a failure here is silent.
  useEffect(() => {
    if (authState !== "signed-in" || !acquisitionId || !def) return;
    let cancelled = false;
    void (async () => {
      const who = await signedInName(user.name);
      if (cancelled) return;
      recordReadReceiptQuietly({
        acquisitionId,
        docKind: "template",
        docKey: templateKey,
        docLabel: def.name,
        openedBy: who,
        source: "document-route",
      });
    })();
    return () => {
      cancelled = true;
    };
  }, [authState, acquisitionId, templateKey, def, user.name]);



  const [values, setValues] = useState<Values>({});
  const companionDocxRef = useRef<{
    key: string;
    bytes: Uint8Array;
  } | null>(null);
  const [touched, setTouched] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [comment, setComment] = useState("");
  const [voteReason, setVoteReason] = useState("");
  const [voteDecision, setVoteDecision] = useState<ReviewDecision | null>(null);
  const [comparables, setComparables] = useState<ComparablesView | null>(null);
  const [checkout, setCheckout] = useState<Checkout | null>(null);
  const [myCheckoutId, setMyCheckoutId] = useState<string | null>(null);
  // Provenance for each drafted paragraph, carried in the saved version.
  const [aiMeta, setAiMeta] = useState<Record<string, DraftProvenance>>({});
  const [sourcePanel, setSourcePanel] = useState<{ title: string; lines: string[] } | null>(null);
  const [draftingKey, setDraftingKey] = useState<string | null>(null);
  // Fields the engine drafted from the record, so the Source panel says so.
  const [draftedFields, setDraftedFields] = useState<Set<string>>(new Set());
  // NF 1858: whether this document is issued as a memorandum, and its header.
  const [memoOn, setMemoOn] = useState<boolean | null>(null);
  const [memoHeader, setMemoHeader] = useState<MemoHeader | null>(null);

  const phase = phaseForTemplate(templateKey);
  const runComparablesFn = useServerFn(samContractAwards);
  const draftItemFn = useServerFn(draftJofocItem);

  // Check-out: the first person to open the document holds it; everyone else
  // sees who and since when, and reads it until that person saves or closes,
  // or thirty minutes pass.
  const heldByOther = !!checkout && checkout.checkout_id !== myCheckoutId;
  const canEdit = canWrite && !heldByOther;

  useEffect(() => {
    if (authState !== "signed-in" || !def) return;
    let cancelled = false;
    let mine: string | null = null;
    const args = {
      acquisitionId,
      templateKey,
      documentName: def.name,
      phase,
      userName: user.name,
    };
    void (async () => {
      try {
        const held = canWrite ? await claimCheckout(args) : await loadCheckout(acquisitionId, templateKey);
        if (cancelled) return;
        setCheckout(held);
        const { data } = await supabase.auth.getUser();
        if (held && data.user?.id === held.user_id) {
          mine = held.checkout_id;
          if (!cancelled) setMyCheckoutId(held.checkout_id);
        }
      } catch {
        // A check-out that cannot be recorded never blocks the document.
      }
    })();
    const release = (reason: string) => {
      if (!mine) return;
      void releaseCheckout({
        checkoutId: mine,
        acquisitionId,
        documentName: def.name,
        phase,
        userName: user.name,
        reason,
      });
      mine = null;
    };
    const onUnload = () => release("Document closed");
    window.addEventListener("beforeunload", onUnload);
    return () => {
      cancelled = true;
      window.removeEventListener("beforeunload", onUnload);
      release("Document closed");
    };
  }, [authState, def, acquisitionId, templateKey, phase, user.name, canWrite]);

  /** P0-3: take the document over from the person holding it, deliberately. */
  const takeOver = async () => {
    if (!def || !checkout) return;
    try {
      const held = await takeOverCheckout({
        acquisitionId,
        templateKey,
        documentName: def.name,
        phase,
        userName: user.name,
        holder: checkout,
      });
      setCheckout(held);
      const { data } = await supabase.auth.getUser();
      if (held && data.user?.id === held.user_id) setMyCheckoutId(held.checkout_id);
      setMessage("You have the document. The hand-over is in the audit log.");
    } catch {
      setMessage("The document could not be taken over just now. Try again in a moment.");
    }
  };


  // Keep the label current for the people who are only reading.
  useEffect(() => {
    if (authState !== "signed-in" || !def || myCheckoutId) return;
    const tick = () => {
      void loadCheckout(acquisitionId, templateKey)
        .then(setCheckout)
        .catch(() => undefined);
    };
    const timer = window.setInterval(tick, 10_000);
    return () => window.clearInterval(timer);
  }, [authState, def, acquisitionId, templateKey, myCheckoutId]);


  const q = useQuery({
    queryKey: ["document-context", templateKey, acquisitionId],
    enabled: authState === "signed-in" && !!def,
    // Votes and comments from other reviewers appear without a reload (cadence in lib/poll.ts).
    ...pollOptions,
    queryFn: async () => {
      const [acq, thr, tpl, polls, rules, users, watchRows, refs, routing, approvals, fileDocs] = await Promise.all([
        supabase.from("acquisition_facts").select("*").eq("acquisition_id", acquisitionId).maybeSingle(),
        supabase.from("thresholds").select("name,value,citation,tier,effective_date,note"),
        supabase.from("templates").select("template_id,name,hq_revision_date,status").eq("name", def!.name).maybeSingle(),
        supabase.from("polls").select("*").eq("acquisition_id", acquisitionId).in("phase", storedPhaseNames(phase)),
        supabase.from("review_rules").select("*"),
        supabase.from("users").select("name,title,center_code,email,telephone"),
        loadWatchRows(),
        loadRegRefs(),
        supabase.from("memo_routing").select("*").eq("document_key", templateKey),
        supabase
          .from("nf1707_approvals")
          .select("approval_role,owner_name,status")
          .eq("acquisition_id", acquisitionId),
        supabase
          .from("documents")
          .select("acquisition_id,template_id,saved_at,version,field_values,templates(name,nf_1098_tab)")
          .eq("acquisition_id", acquisitionId)
          .order("saved_at", { ascending: true }),
      ]);
      if (acq.error) throw new Error(acq.error.message);
      const templateId = tpl.data?.template_id ?? null;
      const acqRecord = acq.data as Record<string, unknown> | null;
      const missionId = String(acqRecord?.["mission_id"] ?? "");
      const naics = String(acqRecord?.["naics_code"] ?? "");
      const centerCode = String(acqRecord?.["center_code"] ?? "");
      // These reads depend only on the acquisition row and template above, not
      // on each other, so they run together. The Center row arrives with the
      // rest instead of last.
      const [
        versions, samCheck, comparablesCheck, mission, evidence, research, latestRun,
        sizeStandard, clauseRows, attachments, auditRows, phasePlan, center, stateLog,
      ] = await Promise.all([
        templateId
          ? supabase
              .from("documents")
              .select(
                "document_id,version,saved_by,saved_at,field_values,ai_model,ai_generated_at,reviewed_by,reviewed_at,issue_on_nf1858,memo_header",
              )
              .eq("acquisition_id", acquisitionId)
              .eq("template_id", templateId)
              .order("version", { ascending: false })
          : Promise.resolve({ data: [], error: null }),
        // The nonresponsibility memo reads the vendor facts from the entity
        // check stored on this acquisition, never from typing.
        supabase
          .from("sam_checks")
          .select("response_json,checked_at")
          .eq("acquisition_id", acquisitionId)
          .order("checked_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        // The price negotiation memorandum reads the comparables check that has
        // already run on this file, so the table is not asked for twice.
        supabase
          .from("sam_checks")
          .select("response_json,checked_at")
          .eq("acquisition_id", acquisitionId)
          .eq("check_type", "Contract awards comparables")
          .order("checked_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        missionId
          ? supabase.from("missions").select("name").eq("mission_id", missionId).maybeSingle()
          : Promise.resolve({ data: null }),
        // The set-aside evidence search, when it has been run, is what the
        // market research memorandum reports.
        supabase
          .from("sam_checks")
          .select("response_json,checked_at")
          .eq("acquisition_id", acquisitionId)
          .like("check_type", "Set-aside entities%")
          .order("checked_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        // Values drafted by the market research evidence engine, with their
        // source and date, so the memorandum shows where each came from.
        supabase
          .from("research_findings")
          .select("target,label,value,source,source_date,confirmed,confirmed_by")
          .eq("acquisition_id", acquisitionId),
        // Public-source searches the engine ran on this file, one line per source.
        // Only the most recent run is printed; earlier runs stay on the file page.
        supabase
          .from("research_runs")
          .select("run_id")
          .eq("acquisition_id", acquisitionId)
          .order("ran_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        naics
          ? supabase
              .from("naics_size_standards")
              .select("standard_type,employees,receipts_usd,citation")
              .eq("naics_code", naics)
              .maybeSingle()
          : Promise.resolve({ data: null }),
        supabase
          .from("clauses")
          .select("clause_number,title,ucf_section,source,status,effective_date,disposition,fill_ins"),
        supabase
          .from("document_attachments")
          .select("acquisition_id,doc_key,doc_label,nf_1098_tab,file_name,created_at")
          .eq("acquisition_id", acquisitionId),
        // The memorandum for record drafts its chronology from the audit trail
        // and the phase plan for this acquisition type.
        // Cached so the 5 s poll does not re-read the full history.
        def?.key === MFR_KEY
          ? queryClient.fetchQuery({
              queryKey: ["document-context", templateKey, acquisitionId, "audit-history"],
              queryFn: () => loadFileAuditHistory(acquisitionId),
              staleTime: 30_000,
              gcTime: Infinity,
            })
          : Promise.resolve([]),
        supabase.from("phase_plan").select("*"),
        centerCode
          ? supabase
              .from("centers")
              .select("center_code,center_name,address_line")
              .eq("center_code", centerCode)
              .maybeSingle()
          : Promise.resolve({ data: null }),
        loadStateAuditRows(acquisitionId),
      ]);
      const latestId = versions.data?.[0]?.document_id ?? null;
      const [comments, researchLog] = await Promise.all([
        latestId
          ? supabase
              .from("comments")
              .select("*")
              .eq("document_id", latestId)
              .order("created_at", { ascending: true })
          : Promise.resolve({ data: [] }),
        latestRun.data?.run_id
          ? supabase
              .from("research_log")
              .select("source,query,result_count,outcome,ran_at")
              .eq("acquisition_id", acquisitionId)
              .eq("run_id", latestRun.data.run_id)
              .order("ran_at", { ascending: true })
          : Promise.resolve({ data: [] }),
      ]);
      return {
        stateLog,
        auditRows: auditRows as {
          action: string;
          field: string | null;
          actor: string | null;
          reason: string | null;
          phase: string | null;
          logged_at: string;
          old_value: string | null;
          new_value: string | null;
        }[],
        phasePlan: (phasePlan.data ?? []) as PhasePlanRow[],
        researchLog: (researchLog.data ?? []) as {
          source: string;
          query: string;
          result_count: number | null;
          outcome: string;
          ran_at: string;
        }[],
        sizeStandard: sizeStandard.data as
          | { standard_type: string; employees: number | null; receipts_usd: number | null; citation: string | null }
          | null,
        clauseRows: (clauseRows.data ?? []) as ClauseRow[],
        attachments: (attachments.data ?? []) as {
          acquisition_id: string | null;
          doc_key: string;
          doc_label: string;
          nf_1098_tab: string | null;
          file_name: string;
          created_at: string;
        }[],
        missionName: (mission.data as { name?: string } | null)?.name ?? missionId,
        evidence: evidence.data ?? null,
        findings: Object.fromEntries(
          (research.data ?? []).map((f) => [
            f.target,
            {
              target: f.target,
              label: f.label,
              value: f.value,
              source: f.source,
              sourceDate: f.source_date,
              confirmed: f.confirmed,
              confirmedBy: f.confirmed_by,
            },
          ]),
        ) as FindingMap,
        center: center.data as { center_name: string; address_line: string | null } | null,
        routing:
          ((routing.data ?? []) as MemoRoutingRow[]).find((r) => r.center_code === centerCode) ?? undefined,
        approvals: (approvals.data ?? []) as { approval_role: string; owner_name: string | null; status: string }[],
        fileDocRows: (fileDocs.data ?? []) as {
          acquisition_id: string | null;
          template_id: string | null;
          saved_at: string | null;
          version: number | null;
          field_values: unknown;
          templates: { name: string; nf_1098_tab: string | null } | null;
        }[],
        fileDocuments: [
          ...new Set(
            ((fileDocs.data ?? []) as { templates: { name: string } | null }[])
              .map((d) => d.templates?.name ?? "")
              .filter(Boolean),
          ),
        ],
        acq: acq.data as Record<string, unknown> | null,
        thresholds: (thr.data ?? []) as ThresholdRow[],
        templateId,
        samCheck: samCheck.data ?? null,
        comparablesCheck: comparablesCheck.data ?? null,
        hqRevision: tpl.data?.hq_revision_date ?? null,
        watchItems: [...itemsFromWatchRows(watchRows), ...itemsFromRefs(refs)],
        polls: (polls.data ?? []) as PollRow[],
        rules: (rules.data ?? []) as ReviewRuleRow[],
        users: (users.data ?? []) as {
          name: string;
          title: string | null;
          center_code: string | null;
          email?: string | null;
          telephone?: string | null;
        }[],
        comments: (comments.data ?? []) as {
          comment_id: string;
          author: string | null;
          body: string | null;
          created_at: string;
        }[],
        versions: (versions.data ?? []) as {
          document_id: string;
          version: number;
          saved_by: string | null;
          saved_at: string | null;
          field_values: unknown;
          ai_model: string | null;
          ai_generated_at: string | null;
          reviewed_by: string | null;
          reviewed_at: string | null;
          issue_on_nf1858?: boolean | null;
          memo_header?: unknown;
        }[],
      };
    },
  });

  const latest = q.data?.versions[0] ?? null;
  const isSampleFile = acquisitionId === "A-2027-0101" || acquisitionId === "A-2027-0102";
  const hasUnreviewedDraft = Object.values(aiMeta).some((meta) => !meta.reviewed);

  const board = useMemo(() => {
    if (!q.data?.acq) return [];
    const ref: RefData = {
      thresholds: (q.data.thresholds ?? []).map((t) => ({
        name: t.name,
        value: t.value === null ? null : Number(t.value),
        citation: t.citation,
        note: t.note,
      })),
      phasePlan: [],
      strategies: [],
    };
    return pollBoard(
      q.data.acq as AcqRow,
      q.data.rules ?? [],
      q.data.polls ?? [],
      ref,
      null,
      phase,
      q.data.users ?? [],
    );
  }, [q.data, phase]);

  const mySeat = board.find((b) => b.reviewer_name === user.name) ?? null;

  const vote = useMutation({
    mutationFn: async ({ choice, reason }: { choice: ReviewDecision; reason: string | null }) => {
      if (await isDemoSession()) throw new Error(DEMO_READ_ONLY_NOTE);
      if (!mySeat?.poll_id) throw new Error("The review request for this phase is not open yet.");
      if (rationaleMissing(choice, reason ?? "")) throw new Error(`${DECISION_LABEL[choice]} needs a written rationale`);
      const { data, error } = await supabase
        .from("polls")
        .update({ vote: choice, reason, voted_at: new Date().toISOString() })
        .eq("poll_id", mySeat.poll_id)
        .select("poll_id");
      if (error) throw new Error(error.message);
      if ((data ?? []).length === 0) throw new Error("no review was updated");
      const entryAudit = decisionAudit({
        decision: choice,
        reviewerName: user.name,
        reviewerRole: mySeat.reviewer_role,
        date: new Date().toISOString().slice(0, 10),
        rationale: reason ?? `${def?.name ?? "document"} reviewed`,
        previousRaw: mySeat.decision,
        previousReason: mySeat.reason,
      });
      const { error: logError } = await writeAudit({
        acquisition_id: acquisitionId,
        actor: user.name,
        action: entryAudit.action,
        field: mySeat.reviewer_role,
        old_value: entryAudit.old_value,
        new_value: entryAudit.new_value,
        reason: entryAudit.reason,
        phase,
      });
      if (logError) throw new Error(logError.message);
    },
    onSuccess: async (_d, v) => {
      setMessage(
        decisionOutcome(v.choice) === "favorable"
          ? `${DECISION_LABEL[v.choice]} recorded. The file resumes if nothing else blocks it.`
          : `${DECISION_LABEL[v.choice]} recorded. The file is on hold until it is resolved.`,
      );
      setVoteDecision(null);
      setVoteReason("");
      await queryClient.invalidateQueries({ queryKey: ["document-context", templateKey, acquisitionId] });
      await queryClient.invalidateQueries({ queryKey: ["acquisition-file", acquisitionId] });
    },
    onError: (e: Error) => setMessage(failureText("The decision did not save", e)),
  });

  const addComment = useMutation({
    mutationFn: async (body: string) => {
      if (!canWrite) throw new Error("Reading only. Editing and saving require Contracting or HQ.");
      if (!latest) throw new Error("Save a version first, then start the thread.");
      const { error } = await supabase
        .from("comments")
        .insert({ document_id: latest.document_id, author: user.name, body });
      if (error) throw new Error(error.message);
      const { error: logError } = await writeAudit({
        acquisition_id: acquisitionId,
        actor: user.name,
        action: "Comment added",
        field: def?.name ?? "document",
        new_value: body.slice(0, 200),
        reason: `Comment on version ${latest.version}`,
        phase,
      });
      if (logError) throw new Error(logError.message);
    },
    onSuccess: async () => {
      setComment("");
      await queryClient.invalidateQueries({ queryKey: ["document-context", templateKey, acquisitionId] });
    },
    onError: (e: Error) => setMessage(`The comment did not save: ${e.message}`),
  });

  const markReviewed = useMutation({
    mutationFn: async () => {
      if (!latest) throw new Error("Save a version first.");
      const reviewedAt = new Date().toISOString();
      const { error } = await supabase
        .from("documents")
        .update({ reviewed_by: user.name, reviewed_at: reviewedAt })
        .eq("document_id", latest.document_id);
      if (error) throw new Error(error.message);
      const { error: logError } = await writeAudit({
        acquisition_id: acquisitionId,
        actor: user.name,
        action: "Document reviewed",
        field: def?.name ?? "document",
        old_value: latest.reviewed_by,
        new_value: user.name,
        reason: `Version ${latest.version} reviewed`,
        phase,
      });
      if (logError) throw new Error(logError.message);
    },
    onSuccess: async () => {
      setMessage("Marked reviewed. The provenance block shows your name and the time.");
      await queryClient.invalidateQueries({ queryKey: ["document-context", templateKey, acquisitionId] });
    },
    onError: (e: Error) => setMessage(`That did not save: ${e.message}`),
  });

  // The contracting officer files one saved version as the official copy for
  // this document on this file. Soft: no clock, no hold, nothing is sent.
  const fileOfficial = useMutation({
    mutationFn: async () => {
      if (!latest) throw new Error("Save a version first.");
      if (!q.data?.templateId) throw new Error("This document has no template record yet.");
      await fileAsOfficialFinal({
        acquisitionId,
        templateId: q.data.templateId,
        documentId: latest.document_id,
        version: latest.version,
        templateName: def?.name ?? "document",
        actor: user.name,
        phase,
      });
    },
    onSuccess: async () => {
      setMessage("Filed as the official copy. Earlier versions stay on the record as drafts.");
      await queryClient.invalidateQueries({ queryKey: ["document-context", templateKey, acquisitionId] });
      await queryClient.invalidateQueries({ queryKey: ["acquisition-file", acquisitionId] });
      await queryClient.invalidateQueries({ queryKey: ["document-versions", acquisitionId] });
    },
    onError: (e: Error) => setMessage(`That did not save: ${e.message}`),
  });

  // Taking the official mark off. The version stays on the file as a draft.
  const unfileOfficial = useMutation({
    mutationFn: async () => {
      if (!latest) throw new Error("Save a version first.");
      await unfileOfficialFinal({
        acquisitionId,
        documentId: latest.document_id,
        version: latest.version,
        templateName: def?.name ?? "document",
        actor: user.name,
        phase,
      });
    },
    onSuccess: async () => {
      setMessage("The official mark was removed. The version stays on the file as a draft.");
      await queryClient.invalidateQueries({ queryKey: ["document-context", templateKey, acquisitionId] });
      await queryClient.invalidateQueries({ queryKey: ["acquisition-file", acquisitionId] });
      await queryClient.invalidateQueries({ queryKey: ["document-versions", acquisitionId] });
    },
    onError: (e: Error) => setMessage(`That did not save: ${e.message}`),
  });

  // Prior awards for this NAICS and PSC, half to double the estimated value.
  const runComparables = useMutation({
    mutationFn: async () => runComparablesFn({ data: { acquisitionId } }),
    onSuccess: (view) => {
      setComparables(view);
      setTouched(true);
      setValues((prev) => ({ ...prev, comparables_summary: comparablesSummary(view) }));
      setMessage(
        view.source !== "live" && view.providerNote
          ? `Comparables loaded. ${view.sourceLabel}. ${view.providerNote}`
          : `Comparables loaded. ${view.sourceLabel}.`,
      );
    },
    onError: (e: Error) => setMessage(`Comparables did not load: ${e.message}`),
  });



  // The comparables check already recorded on this file. The memorandum shows
  // what that check returned; it never stands in for one that has not run.
  const storedComparables = useMemo((): ComparablesView | null => {
    const envelope = (q.data?.comparablesCheck?.response_json ?? null) as Record<string, unknown> | null;
    const view = (envelope?.["normalized"] ?? null) as ComparablesView | null;
    return view && Array.isArray(view.awards) ? view : null;
  }, [q.data?.comparablesCheck]);

  useEffect(() => {
    if (!storedComparables) return;
    setComparables((prev) => prev ?? storedComparables);
  }, [storedComparables]);

  // When no comparables check has run yet, prior T-Minus actions on the same
  // NAICS or PSC stand in for the draft only. They are files in this system,
  // never external awards, and nothing is written back to the record.
  const naicsCode = String(q.data?.acq?.["naics_code"] ?? "");
  const pscCode = String(q.data?.acq?.["psc_code"] ?? "");
  const priorActions = useQuery({
    queryKey: ["local-prior-actions", acquisitionId, naicsCode, pscCode],
    enabled: Boolean(!storedComparables && (naicsCode || pscCode)),
    queryFn: async () => {
      const filter = [naicsCode ? `naics_code.eq.${naicsCode}` : null, pscCode ? `psc_code.eq.${pscCode}` : null]
        .filter(Boolean)
        .join(",");
      const { data, error } = await supabase
        .from("acquisition_facts")
        .select("acquisition_id,title,estimated_value,contract_type,competition,target_award_date,need_date")
        .or(filter)
        .limit(20);
      if (error) throw new Error(error.message);
      return (data ?? []).filter((r) => r.acquisition_id !== acquisitionId).slice(0, 10);
    },
  });

  // What the memorandum draws its comparables paragraph from: the recorded
  // check first, prior actions second, nothing invented either way.
  const comparablesForDraft = useMemo(() => {
    if (storedComparables)
      return {
        source: storedComparables.source,
        sourceLabel: storedComparables.sourceLabel,
        awards: storedComparables.awards,
        checkedAt: storedComparables.checkedAt,
      };
    const rows = priorActions.data ?? [];
    if (!rows.length) return null;
    return {
      source: "local",
      sourceLabel: "from T-Minus prior actions: live feed unavailable",
      awards: rows.map((r) => ({
        agency: `${r.acquisition_id} · ${r.title ?? "Untitled"} (T-Minus prior action)`,
        awardDate: String(r.target_award_date ?? "Not yet determined"),
        pricingType: String(r.contract_type ?? "—"),
        extentCompeted: String(r.competition ?? "—"),
        obligatedAmount: r.estimated_value === null ? null : Number(r.estimated_value),
      })),
    };
  }, [storedComparables, priorActions.data]);

  // The drafted paragraph reports the recorded check rather than opening with
  // "no comparable awards are loaded" when one has already run. Until the
  // officer edits the field, the recorded check wins over the drafted opener.
  useEffect(() => {
    if (!storedComparables || touched) return;
    const text = comparablesSummary(storedComparables);
    setValues((prev) =>
      prev["comparables_summary"] === text ? prev : { ...prev, comparables_summary: text },
    );
  }, [storedComparables, touched, values]);

  // Vendor facts from the stored SAM.gov entity check, offered to the
  // nonresponsibility memo as pre-fill values.
  const samFacts = useMemo(() => {
    const acq = q.data?.acq;
    const envelope = (q.data?.samCheck?.response_json ?? null) as Record<string, unknown> | null;
    const n = (envelope?.["normalized"] ?? null) as Record<string, unknown> | null;
    // The PNM reads the IGCE and quote from the intake answers where the
    // requester recorded them.
    const answers = (acq?.["nf1707_answers"] ?? null) as Record<string, unknown> | null;
    const answerValue = (match: RegExp) => {
      const hit = Object.entries(answers ?? {}).find(([k, v]) => match.test(k) && v !== null && v !== "");
      return hit ? String(hit[1]) : "";
    };
    return {
      sam_legal_name: n?.["legalName"] ?? acq?.["vendor_legal_name"] ?? "",
      sam_uei: n?.["uei"] ?? acq?.["vendor_uei"] ?? "",
      sam_cage: n?.["cage"] ?? acq?.["vendor_cage"] ?? "",
      sam_registration_status: n?.["registrationStatus"] ?? "No entity check recorded",
      sam_registration_expiration: n?.["registrationExpiration"] ?? "—",
      sam_exclusion_flag: n?.["exclusionFlag"] ?? "No entity check recorded",
      sam_integrity_count:
        n?.["integrityRecordsCount"] === undefined ? "—" : String(n["integrityRecordsCount"]),
      sam_checked_at: q.data?.samCheck?.checked_at ?? "No entity check recorded",
      igce_amount: answerValue(/igce|cost_estimate/i) || (acq?.["estimated_value"] ?? ""),
      // On a sole-source file the price the single source proposed is held on
      // the record, entered in the Solicitation/Quote phase.
      quoted_price: acq?.["proposed_price"] ?? answerValue(/quote|proposed_price/i),
      negotiated_price: answerValue(/negotiated_price/i),
      determination: answerValue(/price_determination_statement|price_reasonableness_determination/i),
      proposal_received: acq?.["proposed_price_received"] ?? "",
    } as Record<string, unknown>;
  }, [q.data]);

  // Counts from the stored set-aside evidence search, when it has been run.
  const researchEvidence = useMemo(() => {
    const row = q.data?.evidence as { response_json?: unknown; checked_at?: string | null } | null | undefined;
    if (!row) return null;
    const envelope = (row.response_json ?? {}) as Record<string, unknown>;
    const raw = (envelope["raw"] ?? {}) as Record<string, unknown>;
    const rows = Array.isArray(raw["entityData"]) ? (raw["entityData"] as Record<string, unknown>[]) : [];
    const isSmall = (r: Record<string, unknown>): boolean => {
      for (const [key, value] of Object.entries(r)) {
        if (/smallbusiness/i.test(key)) {
          const v = String(value).trim().toLowerCase();
          if (v === "y" || v === "yes" || v === "true") return true;
        }
        if (value && typeof value === "object" && isSmall(value as Record<string, unknown>)) return true;
      }
      return false;
    };
    const small = rows.filter(isSmall).length;
    return {
      runOn: (row.checked_at ?? "").slice(0, 10),
      sources: rows.length,
      smallBusinesses: small,
    };
  }, [q.data?.evidence]);

  // One line per public-source search, for paragraph 4 and JOFOC item 8.
  const researchLog = useMemo<ResearchLogLine[]>(
    () =>
      (q.data?.researchLog ?? []).map((r) => ({
        source: r.source,
        query: r.query,
        ranAt: String(r.ran_at).slice(0, 10),
        count: r.result_count === null || r.result_count === undefined ? null : Number(r.result_count),
        outcome: r.outcome,
      })),
    [q.data?.researchLog],
  );

  // SBA size standard for the record's NAICS code.
  const sizeStandard = useMemo(() => {
    const row = q.data?.sizeStandard;
    if (!row) return null;
    if (row.receipts_usd)
      return `${money(Number(row.receipts_usd))} average annual receipts (${row.citation ?? "13 CFR 121.201"})`;
    if (row.employees) return `${row.employees} employees (${row.citation ?? "13 CFR 121.201"})`;
    return row.standard_type;
  }, [q.data?.sizeStandard]);

  // The clause packet on this file, the same list the NCMS handoff shows.
  const packetClauses = useMemo<PacketClauseLine[]>(() => {
    if (!q.data?.acq) return [];
    return selectPacketClauses(
      q.data.acq,
      q.data.clauseRows ?? [],
      (q.data.thresholds ?? []).map((t) => ({ name: t.name, value: t.value === null ? null : Number(t.value), citation: t.citation })),
    ).map((c) => ({
      clause_number: c.clause_number,
      title: c.title,
      effective_date: c.effective_date,
      ucf_section: c.ucf_section,
    }));
  }, [q.data]);

  // The SAM.gov notice saved on this file, when there is one. Saving a notice
  // is not publishing it, so the posting date comes only from a publication
  // date carried on the notice itself.
  const noticeFacts = useMemo(() => {
    const rows = (q.data?.fileDocRows ?? []).filter((d) => d.templates?.name === "SAM.gov notice");
    const last = rows[rows.length - 1];
    if (!last)
      return { postedOn: null, saved: false, savedAt: null, closesOn: null, noticeType: null, quotesReceived: null };
    const fv = (last.field_values ?? {}) as Record<string, string>;
    const published = [fv["publication_date"], fv["posted_date"], fv["original_posted_date"]]
      .map((value) => String(value ?? "").trim())
      .find(Boolean) ?? null;
    return {
      postedOn: published ? String(published).slice(0, 10) : null,
      saved: true,
      savedAt: last.saved_at ? String(last.saved_at).slice(0, 10) : null,
      closesOn: fv["response_date"] ?? null,
      noticeType: fv["notice_type"] ?? null,
      quotesReceived: null,
    };
  }, [q.data?.fileDocRows]);

  // One contracting officer per file. The officer named on the record is the
  // contracting officer everywhere a document prints one. When no user row
  // matches that name, the name still prints from the record and the contact
  // details stay blank; the signed-in person is never substituted as the CO.
  const coRecord = useMemo(() => {
    const rows = (q.data?.users ?? []) as {
      name: string;
      email?: string | null;
      telephone?: string | null;
    }[];
    const recordName = String(q.data?.acq?.["co_name"] ?? "").trim();
    if (!recordName) return null;
    const named = rows.find((r) => r.name === recordName);
    return named
      ? { name: named.name, email: named.email ?? null, phone: named.telephone ?? null }
      : { name: recordName, email: null, phone: null };
  }, [q.data]);

  // Generated documents use only a valid target award date. The mission need
  // date is a delivery requirement and never stands in for an award date.
  const awardDate = useMemo(() => {
    const acq = q.data?.acq;
    if (!acq) return null;
    const target = acq["target_award_date"];
    const pick = (v: unknown) => (typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null);
    return pick(target);
  }, [q.data?.acq]);

  // Display chrome follows the shared operational award rule. This is kept
  // separate from awardDate because draft/export context retains its existing
  // source and behavior.
  const chromeState = useMemo(() => {
    if (!q.data?.acq) return null;
    const log = q.data.stateLog ?? [];
    const operational = deriveOverviewAcquisitionState(q.data.acq as unknown as AcqRow, log);
    const templateRows = (q.data.fileDocRows ?? [])
      .filter((row) => row.template_id && row.templates?.name)
      .map((row) => ({ template_id: String(row.template_id), name: String(row.templates?.name) }));
    const ref: RefData = {
      thresholds: (q.data.thresholds ?? []).map((row) => ({
        name: row.name,
        value: row.value === null ? null : Number(row.value),
        citation: row.citation,
        note: row.note,
      })),
      phasePlan: (q.data.phasePlan ?? []).map((row) => ({
        acquisition_type: row.acquisition_type,
        phase: row.phase,
        planned_days: row.planned_days,
      })),
      strategies: [],
    };
    const metrics = computeMetrics(operational.acquisition, {
      plan: q.data.phasePlan ?? [],
      rules: q.data.rules ?? [],
      polls: q.data.polls ?? [],
      ref,
      holdSince: holdSince(q.data.acq as Record<string, unknown>, log),
      awardDate: operational.actualAwardDate,
      attachedKeys: keysFrom(q.data.attachments ?? [], acquisitionId),
      savedKeys: savedDocKeys(q.data.fileDocRows ?? [], templateRows, acquisitionId),
    });
    const view = overviewCountdownView(metrics);
    const keys = {
      acq: metrics.acq,
      attachedKeys: keysFrom(q.data.attachments ?? [], acquisitionId),
      savedKeys: savedDocKeys(q.data.fileDocRows ?? [], templateRows, acquisitionId),
    };
    const readiness = explainWorkReadiness(metrics, keys).state;
    return {
      metrics,
      keys,
      view,
      operational: {
        phase: metrics.currentPhase ?? "Not recorded",
        readiness,
        countdownLine: view.pastTarget
          ? countdownText(view, { omitBadge: view.badge === readiness })
          : view.days === null || !view.prefix
            ? view.caption
            : `${view.prefix}${view.days}${view.badge && view.badge !== readiness ? ` ${view.badge}` : ""}`,
        holdReason: metrics.hold?.reason ?? null,
        holdOwner: metrics.hold?.owner ?? null,
      },
    };
  }, [q.data, acquisitionId]);
  const chromeCountdown = chromeState?.view ?? null;
  const chromeReadiness = chromeState ? explainWorkReadiness(chromeState.metrics, chromeState.keys) : null;

  // Packet documents in the contract file index, in NF 1098 tab order.
  const enclosures = useMemo(() => {
    // An attachment and a document row can record the same official export.
    // The document row's template name stays and wins: an attachment line is
    // dropped only when a live official-export document row on this file
    // carries exactly the same doc_key. Hand uploads, attachments with a
    // different doc_key, and rows with no matching document row stay listed.
    const officialExportKeys = new Set(
      (q.data?.fileDocRows ?? []).flatMap((row) => {
        const fv = (row.field_values ?? {}) as Record<string, unknown>;
        if (fv["__retired"] || fv["kind"] !== "official-export" || !row.templates?.name) return [];
        const key = fv["doc_key"];
        return typeof key === "string" && key ? [key] : [];
      }),
    );
    const items: { tab: string; label: string }[] = [
      ...(q.data?.attachments ?? [])
        .filter((a) => !officialExportKeys.has(a.doc_key) && !isSupersededAttachmentKey(a.doc_key))
        .map((a) => ({ tab: String(a.nf_1098_tab ?? ""), label: a.doc_label })),
      ...(q.data?.fileDocRows ?? [])
        .filter((d) => d.templates?.name && !retiredNote(d.field_values))
        .map((d) => ({ tab: String(d.templates?.nf_1098_tab ?? ""), label: d.templates!.name })),
    ].filter((i) => i.label);
    const seen = new Set<string>();
    return items
      .filter((i) => (seen.has(i.label) ? false : (seen.add(i.label), true)))
      .sort((a, b) => tabRank(a.tab) - tabRank(b.tab))
      .map((i) => (i.tab && i.tab !== "—" && i.tab !== "N/A" ? `Tab ${i.tab}: ${i.label}` : i.label));
  }, [q.data]);

  // The file's own launch sequence, for the chronology memorandum.
  const filePhases = useMemo(
    () =>
      q.data?.acq
        ? buildSequence(q.data.acq as AcqRow, q.data.phasePlan ?? [], todayISO(), daysBetween)
        : [],
    [q.data?.acq, q.data?.phasePlan],
  );

  const draftCtx = useMemo(
    () => ({
      acquisitionId,
      acq: q.data?.acq ?? {},
      missionName: q.data?.missionName ?? "",
      fileDocuments: q.data?.fileDocuments ?? [],
      jofocValues:
        ([...(q.data?.fileDocRows ?? [])]
          .reverse()
          .find((row) => /justification|jofoc/i.test(row.templates?.name ?? ""))?.field_values as
          | Record<string, string>
          | undefined) ?? null,
      // The SAM.gov notice and the evaluation of quotations record, so the
      // basis for award, the criteria and the recommended quoter carry forward
      // without being retyped.
      noticeValues:
        ([...(q.data?.fileDocRows ?? [])]
          .reverse()
          .find((row) => /notice|synopsis/i.test(row.templates?.name ?? ""))?.field_values as
          | Record<string, string>
          | undefined) ?? null,
      evaluationValues:
        ([...(q.data?.fileDocRows ?? [])]
          .reverse()
          .find((row) => /evaluation of quotations/i.test(row.templates?.name ?? ""))?.field_values as
          | Record<string, string>
          | undefined) ?? null,
      pnmValues:
        ([...(q.data?.fileDocRows ?? [])]
          .reverse()
          .find((row) => /price negotiation memorandum/i.test(row.templates?.name ?? ""))?.field_values as
          | Record<string, string>
          | undefined) ?? null,
      evidence: researchEvidence,
      comparables: comparablesForDraft,
      findings: q.data?.findings ?? {},
      researchLog,
      clauses: packetClauses,
      notice: noticeFacts,
      sizeStandard,
      awardDate,
      operational: chromeState?.operational ?? null,
      co: coRecord,
      today: todayISO(),
      audit: (q.data?.auditRows ?? []).map((a) => ({
        action: a.action,
        field: a.field,
        actor: a.actor,
        reason: a.reason,
        phase: a.phase,
        at: a.logged_at,
        oldValue: a.old_value,
        newValue: a.new_value,
      })),
      phases: filePhases.map((p) => ({ phase: p.phase, status: p.status })),
      people: [
        ...((q.data?.users ?? []) as { name: string; title?: string | null }[]).map((u) => ({
          name: u.name,
          title: u.title ?? null,
          aliases: [] as string[],
        })),
        {
          name: user.name,
          title: hasRole("specialist") ? "contract specialist" : user.title,
          aliases: user.email ? [user.email.split("@")[0] ?? ""] : [],
        },
      ],
    }),
    [acquisitionId, q.data, researchEvidence, comparablesForDraft, researchLog, packetClauses, noticeFacts, sizeStandard, awardDate, chromeState, coRecord, filePhases, user, hasRole],
  );

  // The quoters on the evaluation record, so the unsuccessful letter names the
  // company on each slot rather than "Offeror 2", and never the awardee.
  const quoterSlots = useMemo(() => {
    const e = draftCtx.evaluationValues ?? {};
    const awarded = String(e["recommended_quoter"] ?? "").trim().toLowerCase();
    const rows: { slot: string; name: string; awarded: boolean }[] = [];
    for (let i = 1; i <= 4; i += 1) {
      const name = String(e[`quoter_${i}_name`] ?? "").trim();
      if (!name) continue;
      rows.push({ slot: `Offeror ${i}`, name, awarded: name.toLowerCase() === awarded });
    }
    return rows;
  }, [draftCtx.evaluationValues]);



  // Pre-fill from the record, or from the latest saved version.
  useEffect(() => {
    if (!def || !q.data?.acq || touched) return;
    const acqRow = q.data.acq;
    // Facts the record already answers are forced onto the form whichever way
    // it opened: from a stored version or from a fresh draft.
    const forceRecordFacts = (input: Values): Values => {
      const next = { ...input };
      const fact = (key: string) => String(acqRow[key] ?? "").trim();
      const sam = (key: string) => String((samFacts as Record<string, unknown>)[key] ?? "").trim();
      const fillBlank = (key: string, value: string) => {
        if (value && !String(next[key] ?? "").trim()) next[key] = value;
      };
      if (def.key === "jofoc-8a-over-30m") {
        // This justification names the acquisition program itself, never the
        // broader mission shared with unrelated demonstration files.
        const title = fact("title");
        if (title) {
          next["program_name"] = title;
          next["acquisition_identifier"] = `${title} (${acquisitionId})`;
        }
      }
      if (def.key === "pnm") {
        fillBlank("vendor_legal_name", fact("vendor_legal_name") || sam("sam_legal_name"));
        fillBlank("vendor_uei", fact("vendor_uei") || sam("sam_uei"));
        fillBlank("quoted_price", sam("quoted_price"));
        fillBlank("negotiated_price", sam("negotiated_price"));
        fillBlank("determination", sam("determination"));
        // A version saved before the IGCE amount was asked for takes the same
        // record value a fresh draft uses (the IGCE answer, else the estimated value).
        fillBlank("igce_amount", sam("igce_amount"));
      }
      return next;
    };
    const latest = q.data.versions[0]?.field_values;
    if (latest && typeof latest === "object") {
      const stored = { ...(latest as Values) };
      // A stored version keeps its text; the method is carried so the
      // citations still follow this record.
      stored["__method"] = `${String(q.data.acq["acquisition_method"] ?? "")} ${String(
        q.data.acq["contract_format"] ?? "",
      )}`.trim();
      // A stored choice written before an option list was refined still names
      // the same authority, so it is matched back to the option it belongs to
      // rather than opening the field on "Choose one".
      for (const s of def.sections) {
        for (const f of s.fields) {
          if (f.kind !== "select" || !f.options?.length) continue;
          const value = String(stored[f.key] ?? "").trim();
          if (!value || f.options.includes(value)) continue;
          const head = value.split(/\s*\(/)[0]!.trim();
          const match = f.options.find((o) => o === value || (head && o.startsWith(head)));
          if (match) stored[f.key] = match;
        }
      }
      const provenance = stored["__ai_provenance"];
      if (provenance) {
        try {
          setAiMeta(JSON.parse(provenance) as Record<string, DraftProvenance>);
        } catch {
          setAiMeta({});
        }
      }
      // The notice item of the justification reports the state of the notice of intent
      // now, not when the version was saved. A stored status line is refreshed
      // against the notice on the file and the publication date on this form.
      if (def.key === "jofoc") {
        const soleSource = /sole/i.test(String(q.data.acq["competition"] ?? ""));
        const fresh = jofocNoticeStatus({
          soleSource,
          notice: noticeFacts,
          publicationDate: stored["notice_date"] ?? "",
        });
        const previous = stored["notice_status"] ?? "";
        stored["notice_status"] = fresh;
        if (!stored["interested_sources"] || stored["interested_sources"].trim() === previous.trim()) {
          stored["interested_sources"] = fresh;
        }
      }
      // A saved notice whose rule carried the draft date as a posting date
      // reads "Not yet posted." on screen and in exports; nothing is written.
      if (def.key === "sam-notice" && stored["response_rule"]) {
        stored["response_rule"] = repairSavedSamResponseRule(stored) ?? stored["response_rule"];
      }
      // The draft flag is a chip beside the field, never words inside the
      // field body. A stored version written before that rule is cleaned on
      // the way in, and the field still shows its chip.
      const storedMarked = markedKeys(stored);
      if (storedMarked.length) setDraftedFields((prev) => new Set([...prev, ...storedMarked]));
      setValues(forceRecordFacts(stripDraftMarks(stored)));
      return;
    }
    const filled = prefill(def, {
      ...q.data.acq,
      // The record block reads the mission by name, never by its code.
      mission_id: q.data.missionName || q.data.acq["mission_id"],
      ...samFacts,
      acquisition_id: acquisitionId,
    });
    if (def.key === "nf-1707" && !filled["approvals_summary"]) {
      filled["approvals_summary"] = answersSummary(q.data.acq["nf1707_answers"]);
    }
    if (def.key === "jofoc" && !filled["barriers"]) {
      filled["barriers"] =
        "The Agency will continue to examine the market in the future for alternative solutions or new sources before executing any subsequent acquisitions for the same requirements.";
    }
    // The JOFOC's statutory authority is one of the listed options; a longer
    // note on the record is carried into item 5 instead of the picker.
    if (def.key === "jofoc") {
      const options = def.sections.find((x) => x.id === "item4")?.fields[0]?.options ?? [];
      const recorded = filled["authority"] ?? "";
      if (!options.includes(recorded)) {
        // A recorded authority keeps its own basis: it is matched to the option
        // that names it, or left as written when no option does.
        filled["authority"] = matchAuthorityOption(recorded, options) ?? recorded ?? jofocAuthorityDefault(q.data.acq);
        if (!filled["authority"]) filled["authority"] = jofocAuthorityDefault(q.data.acq);
      }
    }
    // The urgency justification gate reads the authority and competition from
    // the record; carry them into the values so the export can be written
    // without retyping facts already on file.
    // The 8(a) justification gate reads the socioeconomic path, the
    // competition and the value from the record.
    if (def.key === "jofoc-8a-over-30m") {
      // This justification describes the acquisition program itself; do not
      // borrow the broader mission name shared by unrelated demonstration files.
      filled["program_name"] = String(q.data.acq["title"] ?? "").trim();
      if (!filled["acquisition_method"]) {
        filled["acquisition_method"] = String(q.data.acq["acquisition_method"] ?? "").trim();
      }
      if (!filled["set_aside"]) {
        filled["set_aside"] = String(
          q.data.acq["set_aside"] ?? q.data.acq["socioeconomic_program"] ?? "",
        ).trim();
      }
      if (!filled["competition_type"]) {
        filled["competition_type"] = String(q.data.acq["competition"] ?? "").trim();
      }
      if (!filled["authority"]) {
        filled["authority"] = String(q.data.acq["jofoc_authority_citation"] ?? "").trim();
      }
      if (!filled["estimated_value"]) {
        filled["estimated_value"] = String(q.data.acq["estimated_value"] ?? "").trim();
      }
    }
    // The prenegotiation position memorandum is a Part 15 document; its gate
    // reads the method, the competition and the value from the record.
    if (def.key === "ppm") {
      if (!filled["acquisition_method"]) {
        filled["acquisition_method"] = String(q.data.acq["acquisition_method"] ?? "").trim();
      }
      if (!filled["competition_type"]) {
        filled["competition_type"] = String(q.data.acq["competition"] ?? "").trim();
      }
      if (!filled["estimated_value"]) {
        filled["estimated_value"] = String(q.data.acq["estimated_value"] ?? "").trim();
      }
    }
    // The postaward notification letters are Part 15 notices; their gate reads
    // the method from the record rather than from the form.
    if (def.key === "postaward-letter-successful" || def.key === "postaward-letter-unsuccessful") {
      if (!filled["acquisition_method"]) {
        filled["acquisition_method"] = String(q.data.acq["acquisition_method"] ?? "").trim();
      }
    }

    if (def.key === "jofoc-urgency") {
      if (!filled["authority"]) {
        const recorded = String(
          q.data.acq["jofoc_authority_citation"] ?? q.data.acq["acquisition_method"] ?? "",
        ).trim();
        if (recorded) filled["authority"] = recorded;
      }
      if (!filled["competition_type"]) {
        const competition = String(q.data.acq["competition"] ?? "").trim();
        if (competition) filled["competition_type"] = competition;
      }
    }
    // The public notice prints the authority as a citation, never the
    // internal picker note the record stores.
    if (def.key === "sam-notice") {
      filled["authority"] = samNoticeAuthority(q.data.acq);
    }
    // One letter per unsuccessful quoter: the link carries the slot, and
    // otherwise the first quoter who was not awarded is opened.
    if (def.key === "postaward-letter-unsuccessful" && !filled["offeror_slot"]) {
      const asked = search.offeror ? `Offeror ${search.offeror}` : "";
      const fallback = quoterSlots.find((r) => !r.awarded)?.slot ?? "";
      filled["offeror_slot"] = asked || fallback;
    }
    // Every document is drafted from the record, section by section, so no
    // field the record can fill is ever opened empty.
    const draft = draftMemoBody(def.key, { ...draftCtx, acq: q.data.acq, values: filled });
    if (def.key === "market-research-memo") {
      // The order of priority starts with existing governmentwide contracts.
      const governmentwideFirst =
        "Existing governmentwide contracts are checked first: whether a commercial product or commercial service on an existing governmentwide contract can meet the requirement (RFO FAR 10.001(f)(1)).";
      const savedCommerciality = [...q.data.fileDocRows]
        .reverse()
        .find((row) => /commerciality determination/i.test(row.templates?.name ?? ""));
      if (savedCommerciality?.field_values && typeof savedCommerciality.field_values === "object") {
        const savedValues = savedCommerciality.field_values as Record<string, unknown>;
        const determination = String(savedValues["determination"] ?? savedValues["commercial_determination"] ?? "").trim();
        if (determination) draft["commercial"] = `${determination} ${governmentwideFirst}`;
      } else {
        draft["commercial"] = `A commerciality determination will be recorded before solicitation. ${governmentwideFirst}`;
      }
    }
    const drafted = applyMemoDraft(filled, draft);
    // The unsuccessful letter reports the value awarded on the evaluation
    // record, not the estimate carried on the intake.
    if (def.key === "postaward-letter-unsuccessful" && draft["contract_value"]) {
      drafted["contract_value"] = draft["contract_value"];
    }
    setDraftedFields(new Set([...draftedKeys(drafted, draft), ...markedKeys(drafted)]));
    setValues(forceRecordFacts(stripDraftMarks(drafted)));
  }, [def, q.data, touched, acquisitionId, samFacts, draftCtx, noticeFacts, search.offeror, quoterSlots]);

  // NF 1858: the flag and the header come from the saved version when there is
  // one, and otherwise from the Center's routing table and the record.
  useEffect(() => {
    if (!def || !q.data?.acq || memoHeader) return;
    const saved = q.data.versions[0];
    const routing = q.data.routing;
    const on =
      typeof saved?.issue_on_nf1858 === "boolean" ? saved.issue_on_nf1858 : memoDefaultFor(def.key, routing);
    const built = buildMemoHeader({
      templateKey: def.key,
      templateName: def.name,
      // The Ref line follows the method on the record. The header can be built
      // before the prefill has carried the method into the values, so it is
      // seeded here the same way the prefill seeds it.
      documentCitation: badgeCitation(def, {
        ...values,
        __method:
          values["__method"] ||
          `${String(q.data.acq["acquisition_method"] ?? "")} ${String(q.data.acq["contract_format"] ?? "")}`.trim(),
      }),
      acquisition: { ...q.data.acq, acquisition_id: acquisitionId },
      centerName: q.data.center?.center_name ?? String(q.data.acq["center_code"] ?? ""),
      centerAddress: q.data.center?.address_line ?? "",
      routing,
      coName: String(q.data.acq["co_name"] ?? coRecord?.name ?? ""),
      enclosures: def.key === "packet-transmittal-memo" ? enclosures : [],
      concurrence: board
        .filter((b) => b.reviewer_role)
        .map((b) => ({ name: b.reviewer_name ?? "", title: b.reviewer_role })),
      today: todayISO(),
    });
    const storedHeader = saved?.memo_header;
    setMemoOn(on);
    const merged = storedHeader && typeof storedHeader === "object" ? { ...built, ...(storedHeader as MemoHeader) } : built;
    // A market-research memorandum is signed by the contracting officer named
    // on the current file. An older saved header must not leave a second name
    // below a FROM line that has already followed the record.
    setMemoHeader(def.key === "market-research-memo" ? { ...merged, signatureName: built.signatureName } : merged);
  }, [def, q.data, memoHeader, acquisitionId, coRecord, enclosures, board]);

  // Situation memo starter: the unexpected-event purpose is chosen for the
  // officer, who can change it. Everything else is drafted from the record.
  useEffect(() => {
    if (!search.situation || def?.key !== MFR_KEY) return;
    setValues((prev) => (String(prev["purpose"] ?? "").trim() ? prev : { ...prev, purpose: MFR_SITUATION_PURPOSE }));
  }, [search.situation, def]);


  // Memorandum for record: the opening line and, for a chronology, the body
  // are drafted again whenever the contracting officer changes the purpose.
  const mfrPurpose = def?.key === MFR_KEY ? `${values["purpose"] ?? ""}|${values["purpose_other"] ?? ""}` : "";
  useEffect(() => {
    if (def?.key !== MFR_KEY || !q.data?.acq || !values["purpose"]) return;
    const draft = draftMemoBody(MFR_KEY, { ...draftCtx, acq: q.data.acq, values });
    setValues((prev) => {
      const next = { ...prev };
      for (const [key, text] of Object.entries(draft)) {
        if (key === "file_tab" && String(prev[key] ?? "").trim()) continue;
        next[key] = text;
      }
      return next;
    });
    setDraftedFields((prev) => new Set([...prev, ...Object.keys(draft)]));
    // The purpose is what the draft follows; the rest of the context is stable.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mfrPurpose]);

  // The memorandum for record is addressed to the contract file, and its
  // subject and Ref line follow the purpose and the authority on the form.
  useEffect(() => {
    if (def?.key !== MFR_KEY || !memoHeader || !q.data?.acq) return;
    const purpose = mfrPurposeLabel(values);
    const pr = String(q.data.acq["pr_number"] ?? "").trim();
    const title = String(q.data.acq["title"] ?? "").trim();
    const subject = `Memorandum for Record${purpose ? ` — ${purpose}` : ""}${title ? ` — ${title}` : ""}${
      pr ? ` — PR ${pr}` : ""
    }`;
    const authority = String(values["authority"] ?? "").trim();
    const ref = authority ? [authority] : [];
    if (memoHeader.subject === subject && memoHeader.ref.join("|") === ref.join("|")) return;
    setMemoHeader({ ...memoHeader, subject, ref });
  }, [def?.key, memoHeader, q.data?.acq, values]);

  const estimatedValue = q.data?.acq?.["estimated_value"] ? Number(q.data.acq["estimated_value"]) : null;
  const signature = useMemo(
    () => (def?.signature ? def.signature(estimatedValue, q.data?.thresholds ?? []) : undefined),
    [def, estimatedValue, q.data?.thresholds],
  );

  const errors = def ? validate(def, values) : {};
  const errorCount = Object.keys(errors).length;
  const rendered = def ? renderDocument(def, values, acquisitionId, signature) : null;
  // Export from the same method-aware values used by the on-screen Binding
  // line. Saved versions can predate __method; they must not select stale
  // generic standing text in the signed Word memorandum.
  const documentValues = {
    ...values,
    __method:
      values["__method"] ||
      `${String(q.data?.acq?.["acquisition_method"] ?? "")} ${String(
        q.data?.acq?.["contract_format"] ?? "",
      )}`.trim(),
  };
  const exportRendered = def ? renderDocument(def, documentValues, acquisitionId, signature) : null;
  const memoDoc = exportRendered && memoHeader ? buildMemoDoc(exportRendered, memoHeader, def?.key) : null;
  const exportContext = def && q.data?.acq ? {
    def,
    values,
    acquisitionId,
    // The record itself, so a method gate can read the file rather than the form.
    acq: q.data.acq as Record<string, unknown>,
    coName: String(q.data.acq["co_name"] ?? coRecord?.name ?? ""),
    coTitle: "Contracting Officer",
    approvingOfficialTitle: approvingOfficialTitle(
      q.data.routing?.approving_official_title,
      !(signature && signature.blocks.length > 2),
    ),
    technicalRepresentativeName: technicalRepresentative(q.data.acq as Record<string, unknown>),
    centerName: q.data.center?.center_name ?? String(q.data.acq["center_code"] ?? ""),
    centerAddress: q.data.center?.address_line ?? "",
    // The prepared date is the Center working calendar date, read in Central
    // time, so a late-evening export never prints tomorrow from UTC.
    preparedDate: new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric", timeZone: "America/Chicago" }),
    organizationCode: String(q.data.acq["co_code"] ?? q.data.acq["requester_org_code"] ?? q.data.acq["branch_code"] ?? q.data.acq["org_code"] ?? ""),
    additionalApprovalRequired: Boolean(signature && signature.blocks.length > 2),
    researchLog: q.data.researchLog,
    sizeStandard: q.data.sizeStandard?.citation ?? null,
    priorTminusActionCount: comparablesForDraft?.source === "local" ? comparablesForDraft.awards.length : 0,
    // Live JOFOC approval-tier rows so the signature band is amount-driven.
    thresholds: (q.data.thresholds ?? []).map((t) => ({
      name: t.name,
      value: t.value === null || t.value === undefined ? null : Number(t.value),
    })),
  } : undefined;
  const companionPrefetchKey = useMemo(
    () =>
      def &&
      (def.key === "postaward-letter-successful" || def.key === "postaward-letter-unsuccessful")
        ? `${def.key}:${JSON.stringify(values)}`
        : "",
    [def, values],
  );
  useEffect(() => {
    if (!exportContext || !companionPrefetchKey || isPart15NotificationPath(exportContext)) {
      companionDocxRef.current = null;
      return;
    }
    let cancelled = false;
    companionDocxRef.current = null;
    const generate =
      def?.key === "postaward-letter-successful"
        ? generatePostawardSuccessCompanionDocx
        : generatePostawardUnsuccessCompanionDocx;
    void generate(exportContext)
      .then((bytes) => {
        if (!cancelled) companionDocxRef.current = { key: companionPrefetchKey, bytes };
      })
      .catch(() => {
        if (!cancelled) companionDocxRef.current = null;
      });
    return () => {
      cancelled = true;
    };
  }, [companionPrefetchKey, def?.key, exportContext]);
  const setMemo = <K extends keyof MemoHeader>(key: K, value: MemoHeader[K]) =>
    setMemoHeader((prev) => (prev ? { ...prev, [key]: value } : prev));
  const linesToList = (text: string) => text.split("\n").map((l) => l.trim()).filter(Boolean);

  // Export headers use only the recorded target award date.
  const targetDate = awardDate;
  const daysToAward = targetDate ? daysBetween(todayISO(), targetDate) : null;
  const exportHeaderLine = `${acquisitionId} · ${
    chromeCountdown?.pastTarget
      ? countdownText(chromeCountdown)
      : chromeCountdown && chromeCountdown.mode === "hold" && chromeCountdown.days !== null
        ? countdownText(chromeCountdown)
        : daysToAward === null
          ? `Target award date: ${ANTICIPATED_AWARD_TBD}. ${ANTICIPATED_AWARD_TBD_NOTE}`
          : daysToAward < 0
            ? `${Math.abs(daysToAward)} ${dayWord(Math.abs(daysToAward))} past target`
            : `${daysToAward} ${dayWord(daysToAward)} to award`

  }`;
  const headerLine = `${acquisitionId} · ${
    !chromeCountdown
      ? "Not recorded"
      : chromeCountdown.pastTarget
        ? countdownText(chromeCountdown)
        : chromeCountdown.days === null
          ? chromeCountdown.caption
          : chromeCountdown.mode === "hold"
            ? `${chromeCountdown.prefix}${chromeCountdown.days} HOLD`
            : `${chromeCountdown.prefix}${chromeCountdown.days}${chromeCountdown.badge ? ` ${chromeCountdown.badge}` : ""} (${chromeCountdown.caption})`
  }`;

  const save = useMutation({
    mutationFn: async () => {
      if (!def || !q.data?.templateId) throw new Error("This template is not loaded in the database.");
      const nextVersion = (q.data.versions[0]?.version ?? 0) + 1;
      const savedAt = new Date().toISOString();
      // Editing a drafted paragraph clears its AI label on the new version.
      const keptMeta: Record<string, DraftProvenance> = {};
      for (const [key, meta] of Object.entries(aiMeta)) {
        if ((values[key] ?? "") === meta.draftText) keptMeta[key] = meta;
      }
      const fieldValues: Values = { ...values };
      if (Object.keys(keptMeta).length) fieldValues["__ai_provenance"] = JSON.stringify(keptMeta);
      else delete fieldValues["__ai_provenance"];
      setAiMeta(keptMeta);
      // A memorandum for record is filed under the tab the officer picked.
      if (def.key === MFR_KEY) {
        const picked = String(values["file_tab"] ?? "").trim() || "001";
        fieldValues["__tab"] = picked;
      }
      const { error } = await supabase.from("documents").insert({
        acquisition_id: acquisitionId,
        template_id: q.data.templateId,
        field_values: fieldValues as never,
        version: nextVersion,
        issue_on_nf1858: memoOn ?? false,
        memo_header: (memoOn && memoHeader ? memoHeader : null) as never,
        saved_by: user.name,
        saved_at: savedAt,
        // Fields are drawn from the record by the template engine, so the
        // provenance names the engine, and review is recorded separately.
        ai_model: "T-Minus template engine (record pre-fill, no model)",
        ai_generated_at: savedAt,
      });
      if (error) throw new Error(error.message);
      // The recommended quoter on the evaluation record becomes the vendor on
      // the record, so the price memorandum and the responsibility check read
      // the same name and UEI without anyone retyping them.
      if (def.key === "evaluation-of-quotations") {
        const name = String(values["recommended_quoter"] ?? "").trim();
        const uei = String(values["recommended_uei"] ?? "").trim();
        if (name || uei) {
          await supabase
            .from("acquisition_facts")
            .update({
              ...(name ? { vendor_legal_name: name } : {}),
              ...(uei ? { vendor_uei: uei } : {}),
            })
            .eq("acquisition_id", acquisitionId);
          await writeAudit({
            acquisition_id: acquisitionId,
            actor: user.name,
            action: "Recommended quoter carried to the record",
            field: "vendor_legal_name",
            old_value: String(q.data.acq?.["vendor_legal_name"] ?? ""),
            new_value: [name, uei].filter(Boolean).join(" · "),
            reason: "Recommended on the evaluation of quotations record",
            phase,
          });
        }
      }
      const { error: logError } = await writeAudit({
        acquisition_id: acquisitionId,
        actor: user.name,
        action:
          def.key === MFR_KEY
            ? `Memorandum for Record added: ${mfrPurposeLabel(values) || "purpose not stated"}`
            : "Document saved",
        field: def.name,
        old_value: q.data.versions[0] ? `version ${q.data.versions[0].version}` : null,
        new_value: `version ${nextVersion}`,
        reason: `${def.name} was saved as version ${nextVersion}`,
        phase,
      });
      if (logError) throw new Error(logError.message);
      return nextVersion;
    },
    onSuccess: async (v) => {
      setMessage(`Saved as version ${v}.`);
      // Saving releases the check-out, so the next person can edit.
      if (myCheckoutId && def) {
        await releaseCheckout({
          checkoutId: myCheckoutId,
          acquisitionId,
          documentName: def.name,
          phase,
          userName: user.name,
          reason: "Saved a version",
        });
        setMyCheckoutId(null);
        setCheckout(null);
      }
      await queryClient.invalidateQueries({ queryKey: ["document-context", templateKey, acquisitionId] });
    },

    onError: (e: unknown) =>
      setMessage(
        e instanceof Error ? `The save did not finish: ${e.message}` : "The save did not finish. Try again.",
      ),
  });

  const documentSaveState: SaveState = heldByOther && checkout
    ? { kind: "readonly", reason: `Checked out by ${checkout.user_name}` }
    : !canWrite && !readOnly
      ? { kind: "readonly", reason: "Editing requires Contracting or HQ" }
      : save.isPending
        ? { kind: "saving" }
        : save.isError
          ? {
              kind: "error",
              text: save.error instanceof Error ? `The save did not finish: ${save.error.message}` : "The save did not finish. Try again.",
            }
          : save.isSuccess
            ? { kind: "saved", version: save.data }
            : latest
              ? { kind: "saved", version: latest.version, at: latest.saved_at, by: latest.saved_by }
              : { kind: "none" };
  const documentSections = useMemo(() => (def ? visibleSections(def, values) : []), [def, values]);
  const documentNavItems: MissionNavItem[] = useMemo(
    () => def
      ? [
          { id: "doc-save-export", label: "Save & export" },
          ...documentSections.map((section) => {
            const remaining = visibleFields(section, values).filter((field) => Boolean(errors[field.key])).length;
            return {
              id: `doc-sec-${section.id}`,
              label: section.title,
              badge: remaining ? { tone: "watch" as const, text: `${remaining} to complete` } : null,
            };
          }),
          ...(signature ? [{ id: "doc-signatures", label: "Signatures" }] : []),
          { id: "doc-nf1858", label: "NF 1858 memorandum" },
          ...(def.key === "pnm" ? [{ id: "doc-comparables", label: "Comparables lookup" }] : []),
          { id: "doc-provenance", label: "Provenance" },
          { id: "doc-official-copy", label: "Official file copy" },
          { id: "doc-poll", label: "Reviews and approvals" },
          { id: "doc-comments", label: "Comments" },
          { id: "doc-versions", label: "Versions" },
          { id: "doc-regulations", label: "Regulations" },
          { id: "doc-defect", label: "Report a defect" },
        ].filter((item, index, all) => {
          // No entry repeats: a template section and a page panel with the
          // same title (the PNM's "Comparable prior awards") list once.
          const key = item.label.trim().toLowerCase();
          return all.findIndex((other) => other.id === item.id || other.label.trim().toLowerCase() === key) === index;
        })
      : [],
    [def, documentSections, errors, signature, values],
  );

  if (!def) {
    return (
      <AppShell>
        <PageHeader title="Template not found" lead="Go back to Templates and choose a live template." />
        <Link to="/templates" className="text-primary">
          Back to Templates
        </Link>
      </AppShell>
    );
  }

  // The nonresponsibility memo exists only on that finding. On a finding of
  // responsible, the signature on the SF 1449 is the determination.
  if (def.key === "nonresponsibility" && q.data?.acq && q.data.acq["responsibility_finding"] !== "nonresponsibility") {
    return (
      <AppShell>
        <PageHeader
          title="No memorandum is written for this file"
          lead={`${acquisitionId} · the responsibility finding is not nonresponsibility.`}
        />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">
          The contracting officer's signature on the SF 1449 is the affirmative responsibility determination
          (RFO FAR 9.105-2(a)(1)). A separate memorandum is written only on a finding of nonresponsibility.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }

  const guidance = newerGuidance(def.badge.citation, def.badge.effective ?? null, q.data?.watchItems ?? []);

  const recordValue = (bind: string) => {
    const v = (q.data?.acq as Record<string, unknown> | null | undefined)?.[bind];
    return v === null || v === undefined || v === "" ? "not recorded" : String(v);
  };

  /** A read-only field: its saved value, else the bound record value, else "Not recorded". */
  const readonlyText = (f: { key: string; bind?: string }): string => {
    const saved = String(values[f.key] ?? "").trim();
    const bound = f.bind ? (q.data?.acq as Record<string, unknown> | null | undefined)?.[f.bind] : undefined;
    const raw = saved || (bound === null || bound === undefined ? "" : String(bound).trim());
    if (!raw) return "Not recorded";
    return /(^|_)(value|amount|price)$/.test(f.bind ?? f.key) && /^\d+(\.\d+)?$/.test(raw)
      ? `$${Number(raw).toLocaleString("en-US")}`
      : raw;
  };

  /** Where a filled field came from: the intake field, the template item, or the citation. */
  const openSource = (s: SectionDef, f: { key: string; label: string; bind?: string }) => {
    const meta = aiMeta[f.key];
    const lines: string[] = [];
    if (meta) {
      lines.push(`AI draft written by ${meta.model} on ${new Date(meta.generatedAt).toLocaleString()}.`);
      lines.push(`Template revision: ${meta.templateRevision} · Item: ${meta.templateItem}`);
      lines.push(`Template instruction used: ${meta.templateText}`);
      lines.push(`Record fields used: ${meta.recordFields.map((r) => `${r.field} = ${r.value}`).join("; ")}`);
      lines.push(meta.intakeAnswersUsed ? "Intake answers were included in the draft." : "Intake answers were not included in this draft.");
      lines.push(meta.reviewed ? "Marked reviewed by the contracting officer." : "AI draft, not yet reviewed.");
    } else if (draftedFields.has(f.key)) {
      lines.push("Drafted from the record, confirm.");
      if (f.bind) lines.push(`Record field: ${f.bind} = ${recordValue(f.bind)}`);
      if (/market_research|research|findings|clause_note/.test(f.key) && researchLog.length) {
        lines.push("Research log lines used:");
        for (const l of researchLog) lines.push(`${l.source} · ${l.ranAt} · ${l.count ?? l.outcome}`);
      }
      lines.push(`Written into: ${s.title}`);
    } else if (f.bind) {
      lines.push(`Intake field: ${f.bind}`);
      lines.push(`Value on the record: ${recordValue(f.bind)}`);
      lines.push(`Written into: ${s.title}`);
      lines.push(`Template revision: ${def.badge.revision}`);
    } else {
      lines.push(`Typed on this template. Template revision: ${def.badge.revision}`);
      lines.push(`Item: ${s.title}`);
    }
    const cite = sectionCite(s);
    if (cite) lines.push(`Authority citation: ${cite}`);
    setSourcePanel({ title: f.label, lines });
  };

  // Citations follow the method on the record, whether or not the values
  // carry it yet.
  const citationValues = documentValues;
  // Until the record has loaded, the template's own citation stands; a
  // method-dependent citation is never guessed from empty values.
  const methodKnown = Boolean(citationValues["__method"]);
  const badgeCite = methodKnown ? badgeCitation(def, citationValues) : def.badge.citation;
  const badgeNoteText = methodKnown ? badgeNote(def, citationValues) : def.badge.note;
  const sectionCite = (s: SectionDef) => (methodKnown ? sectionCitation(s, citationValues) : s.citation);
  // The standing body follows the same method test as the citation, so a
  // simplified file never reads Part 15 prose.
  const sectionBody = (s: SectionDef) =>
    methodKnown ? sectionStandingText(s, citationValues) : s.standingText;
  const badgeCiteStatus = citeStatus(badgeCite, citeCorpus.rows, citeCorpus.state);
  const badgeTextState = useCitationTextState(badgeCite);

  // Keep this refusal after every hook in the component. Returning before the
  // citation hook once the record arrives changes the hook count and sends the
  // user to the generic route error boundary instead of this method-gate copy.
  if (def.key === "ppm" && exportContext && !isPpmPath(exportContext)) {
    return (
      <AppShell>
        <PageHeader
          title="Prenegotiation position memorandum not available"
          lead={`${acquisitionId} · this record is not on a Part 15 negotiation path.`}
        />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">
          A prenegotiation position memorandum requires a Part 15 negotiation path. Record Part 15 on the
          acquisition before opening or exporting this memorandum. Commercial and simplified files record price
          reasonableness under Parts 12 and 13 instead.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }

  // The set-aside preaward notice runs on a Part 15 negotiated set-aside only.
  // A commercial or simplified file is refused rather than shown Part 15 prose.
  if (
    def.key === "setaside-preaward-notification" &&
    exportContext &&
    !isSetAsidePreawardPath(exportContext)
  ) {
    return (
      <AppShell>
        <PageHeader
          title="Set-aside preaward notification not available"
          lead={`${acquisitionId} · this record is not on a Part 15 negotiated set-aside.`}
        />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">
          The preaward notice to the apparent successful offeror runs under RFO FAR 15.206-1(b)(1) with the size
          status challenge period at RFO FAR 19.201-2(d)(1). Record an RFO FAR Part 15 negotiated path and a small
          business set-aside on the acquisition before opening or exporting this notice. Commercial and
          simplified files notify under Parts 12 and 13 instead.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }

  // A DRFP cover is used only for a competed RFO FAR Part 15 negotiated path.
  // Commercial, simplified, and sole-source records get an honest refusal.
  if (def.key === "drfp-cover-letter" && exportContext && !isDrfpCoverPath(exportContext)) {
    return (
      <AppShell>
        <PageHeader
          title="Draft RFP cover letter not available"
          lead={`${acquisitionId} · this record is not on a competed RFO FAR Part 15 negotiated path.`}
        />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">
          The HQ Draft RFP cover letter is for competed negotiated acquisitions. Record the RFO FAR Part 15
          competitive path before opening or exporting it. Commercial, simplified, and sole-source files do not
          receive this Part 15 cover.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }

  // Options are justified on a negotiated or sealed bid solicitation path.
  // Commercial and simplified files are refused rather than shown this memo.
  if (
    def.key === "option-justification" &&
    exportContext &&
    !isOptionJustificationPath(exportContext)
  ) {
    return (
      <AppShell>
        <PageHeader
          title="Option justification not available"
          lead={`${acquisitionId} · this record is not on a solicitation path that justifies options.`}
        />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">
          The HQ option justification is written before a negotiated or sealed bid solicitation includes
          options, under RFO FAR 17.201-1 and RFO FAR 17.201-2 in the format at NFS CG 1817.25. Record that path on the
          acquisition before opening or exporting it. Commercial and simplified files do not use this memorandum.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }

  // An option is exercised on an awarded contract. The protected commercial
  // samples are refused rather than shown this determination.
  if (
    def.key === "option-exercise-determination" &&
    exportContext &&
    isSoftWalkCommercialSample({ acquisition_id: acquisitionId })
  ) {
    return (
      <AppShell>
        <PageHeader
          title="Option exercise determination not available"
          lead={`${acquisitionId} · this record is not on a path that exercises a contract option.`}
        />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">
          The HQ determination is written on an awarded contract that carries an option, under RFO FAR 17.201-2
          and NFS CG 1817.27 and 1817.28. Record the awarded contract and the option being exercised before
          opening or exporting it.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }

  // The letter contract justification belongs to an undefinitized action path.
  // The protected commercial samples are refused rather than shown this face.
  if (
    def.key === "uca-letter-contract" &&
    exportContext &&
    isSoftWalkCommercialSample({ acquisition_id: acquisitionId })
  ) {
    return (
      <AppShell>
        <PageHeader
          title="Letter contract justification not available"
          lead={`${acquisitionId} · undefinitized actions and letter contracts do not apply to this commercial or simplified acquisition.`}
        />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">
          The HQ justification is written on an undefinitized contract action or a letter contract, under
          RFO FAR 16.603 and NFS CG 1816.65 and 1816.66. Record that action before opening or exporting it.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }

  // A blackout notice is issued for a competed Part 15 final solicitation.
  // Commercial, simplified, and other non-blackout paths get an honest refusal.
  if (def.key === "blackout-notice" && exportContext && !isBlackoutPath(exportContext)) {
    return (
      <AppShell>
        <PageHeader title="Blackout notice not applicable" lead={acquisitionId} />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">{BLACKOUT_UNAVAILABLE}</p>
        <p className="mt-3 max-w-[80ch] text-[15px] leading-[22px]">
          The HQ blackout notice is issued when a final RFP or solicitation is released for a competitive
          acquisition. Record the competed Part 15 final-solicitation path before opening or exporting this
          notice.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }

  // The brand-name justification belongs to a RFO FAR Part 16 ordering path. The
  // protected commercial samples are refused rather than shown this face.
  if (
    def.key === "fair-opportunity-brand-name" &&
    exportContext &&
    isSoftWalkCommercialSample({ acquisition_id: acquisitionId })
  ) {
    return (
      <AppShell>
        <PageHeader
          title="Brand name justification not available"
          lead={`${acquisitionId} · fair opportunity and brand name exceptions do not apply to this commercial or simplified acquisition.`}
        />
        <p className="max-w-[80ch] text-[15px] leading-[22px]">
          The HQ justification is written on an order placed under a multiple-award contract, where fair
          opportunity would otherwise apply. Record the ordering vehicle and the brand-name item before
          opening or exporting it.
        </p>
        <p className="mt-6">
          <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
            Back to the acquisition file
          </Link>
        </p>
      </AppShell>
    );
  }





  const runDraft = async (key: string) => {
    setDraftingKey(key);
    setMessage(null);
    try {
      const result = await draftItemFn({ data: { acquisitionId, fieldKey: key } });
      setTouched(true);
      setValues((prev) => ({ ...prev, [key]: result.text }));
      setAiMeta((prev) => ({ ...prev, [key]: result.provenance }));
      setMessage(`Drafted with ${result.provenance.model}. Read it, edit it, then save a version.`);
    } catch (e) {
      setMessage(e instanceof Error ? `The draft did not run: ${e.message}` : "The draft did not run.");
    } finally {
      setDraftingKey(null);
    }
  };

  const set = (key: string, v: string) => {
    setTouched(true);
    setValues((prev) => {
      const next = { ...prev, [key]: v };
      // Choosing the offeror rewrites the letter for that quoter, so one row
      // yields one letter per unsuccessful offeror on the evaluation record.
      if (key === "offeror_slot" && def && def.key === "postaward-letter-unsuccessful" && q.data?.acq) {
        for (const field of ["company_name", "addressee", "offeror_uei", "quotation_summary"]) next[field] = "";
        const draft = draftMemoBody(def.key, { ...draftCtx, acq: q.data.acq, values: next });
        return applyMemoDraft(next, draft);
      }
      return next;
    });
  };

  return (
    <AppShell>
      <PageHeader
        title={def.name}
        lead={`${acquisitionId} · ${methodKnown && def.leadFor ? def.leadFor(citationValues) : def.lead}${
          Object.values(aiMeta).some((m) => !m.reviewed) ? " · contains an AI draft, not yet reviewed" : ""
        }`}
      />
      <WorkShellHeader
        acquisitionId={acquisitionId}
        title={String(q.data?.acq?.["title"] ?? "") || null}
        readiness={chromeReadiness}
        countdown={chromeCountdown}
        saveState={documentSaveState}
        completion={errorCount ? `${errorCount} required field${errorCount === 1 ? "" : "s"} to complete` : "Required fields complete"}
      />
      <WorkShellLayout
        nav={<MissionNavigator items={documentNavItems} label="In this document" ariaLabel="In this document" />}
      >
      <WithDetailsPanel
        className="mc-shell-document-content mc-doc-with-details"
        panelLabel="About this document"
        panel={
            <>
              <DetailsSection title="This document">
              <section aria-label="Version badge" className="mc-doc-about">
                <p className="text-[15px] font-semibold leading-[22px]">
                  {def.badge.revision}
                  {def.tab === "—" ? "" : ` · NF 1098 tab ${def.tab}`}
                </p>
                <p className="mt-1 text-[13px] text-muted-foreground">
                  {badgeCite} · {def.badge.tier === "binding" ? "Binding" : "Guidance"}
                </p>
                {badgeTextState === "heading" ? (
                  <p className="mt-1 text-[13px] text-muted-foreground">{CITE_HEADING_ONLY_NOTE}</p>
                ) : badgeCiteStatus.kind === "stub" && badgeTextState === "none" ? (
                  <p className="mt-1 text-[13px] text-muted-foreground">{badgeCiteStatus.note}</p>
                ) : null}
                <p className="mt-1">
                  <ShowTheText citation={badgeCite} />
                </p>
                {badgeNoteText ? (
                  <div className="mt-1 flex items-start gap-2 text-[13px] text-muted-foreground">
                    <p>{badgeNoteText}</p>
                    {def.badge.corrections?.length ? (
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              type="button"
                              aria-label="Show the three citation corrections"
                              className="shrink-0 rounded-lg border border-border px-2 text-foreground"
                            >
                              Details
                            </button>
                          </TooltipTrigger>
                          <TooltipContent className="max-w-sm bg-popover text-popover-foreground">
                            <ul className="list-disc space-y-1 pl-4">
                              {def.badge.corrections.map((correction) => (
                                <li key={correction}>{correction}</li>
                              ))}
                            </ul>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    ) : null}
                  </div>
                ) : null}
                {guidance ? (
                  <p className="mt-2 text-[13px]">
                    <StatusMark color="var(--attention)">Newer guidance published; review</StatusMark>{" "}
                    {guidance.url ? (
                      <a href={guidance.url} target="_blank" rel="noreferrer" className="text-primary underline">
                        {guidance.title}
                      </a>
                    ) : (
                      <span className="text-muted-foreground">{guidance.title}</span>
                    )}
                    <span className="text-muted-foreground"> · {guidance.date ?? "date not published"}</span>
                  </p>
                ) : null}
                <p className="mt-1 text-[13px] text-muted-foreground" data-numeric>
                  {headerLine}
                  {estimatedValue !== null ? ` · IGCE ${formatMoney(estimatedValue)}` : ""}
                </p>
              </section>
              </DetailsSection>
              {def.key === "sam-notice" ? (
                <DetailsSection title="Posting">
                  <DetailsList
                    items={[
                      { term: "Posted to SAM.gov", value: String(values["posted_date"] ?? "").trim() || "Not recorded" },
                      { term: "Response date", value: String(values["response_date"] ?? "").trim() || "Not set" },
                    ]}
                  />
                </DetailsSection>
              ) : null}
              <DetailsSection title="Activity">
                <div className="mc-doc-activity flex flex-wrap items-center gap-3">
                  <Nova acquisitionId={acquisitionId} documentLabel={def.name} />
                  <p className="text-[13px] text-muted-foreground">
                    <DocReadCount acquisitionId={acquisitionId} docKind="template" docKey={templateKey} />
                  </p>
                </div>
              </DetailsSection>
            </>
        }
      >

      {/* A standalone draft is taken outside the launch sequence. It saves and
          exports like any document and adds no required row to the file. */}
      {search.standalone ? (
        <p className="mb-4 max-w-[80ch] border-l-2 border-border pl-3 text-[13px] text-muted-foreground">
          Standalone draft. This document was started outside the launch sequence for {acquisitionId}.
          It is not a required beat, and saving it does not add a requirement to the file.
          {search.situation ? " Situation memo starter: the scaffold is drafted from the record; confirm every line." : ""}
        </p>
      ) : null}



      {def.key === "postaward-letter-unsuccessful" && quoterSlots.some((r) => !r.awarded) ? (
        <section aria-label="Letter for each unsuccessful quoter" className="mb-4 max-w-[80ch]">
          <p className="text-[13px] text-muted-foreground">
            One letter per unsuccessful quoter on the evaluation record. Choose a company to write its
            letter; the letter is saved as its own version.
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {quoterSlots
              .filter((r) => !r.awarded)
              .map((r) => {
                const current = (values["offeror_slot"] ?? "") === r.slot;
                return (
                  <button
                    key={r.slot}
                    type="button"
                    aria-pressed={current}
                    onClick={() => set("offeror_slot", r.slot)}
                    className={`rounded-lg border px-3 py-1 text-[13px] ${
                      current ? "border-primary text-primary" : "border-border text-foreground"
                    }`}
                  >
                    {r.name}
                  </button>
                );
              })}
          </div>
        </section>
      ) : null}


      {/* Until the record is in hand the form frame is drawn empty of fields,
          so no field reads blank while its value is still on the way. */}
      {q.isLoading ? (
        <div className="max-w-[80ch]">
          <p role="status" aria-live="polite" className="sr-only">Loading the record.</p>
          <div aria-hidden="true" className="mc-work-form-section mb-6 min-w-0">
            <span className="block h-5 w-1/3 animate-pulse rounded-sm bg-muted" />
            {[0, 1].map((i) => (
              <div key={i} className="mt-5 grid min-w-0 gap-2">
                <span className="block h-3 w-1/4 animate-pulse rounded-sm bg-muted" />
                <span className="block h-9 w-full animate-pulse rounded-md bg-muted" />
              </div>
            ))}
          </div>
          <div aria-hidden="true" className="mb-10 h-64 min-w-0 rounded-xl border border-dashed border-border" />
        </div>
      ) : (
      <>
      {heldByOther && checkout ? (
        <div
          role="status"
          className="mc-work-form-section mb-4 max-w-[80ch] text-[15px] leading-[22px]"
        >
          <p>
            Checked out by {checkout.user_name} since{" "}
            {checkoutTime(checkout.checked_out_at).replace(/\.?$/, ".")} What is saved is shown here and
            reads as written; the fields are read-only for you until that person saves or closes the
            document, or thirty minutes pass.
          </p>
          {canWrite ? (
            <p className="mt-2">
              <button
                type="button"
                className="text-primary underline"
                onClick={() => void takeOver()}
              >
                Take over the document
              </button>{" "}
              <span className="text-muted-foreground">
                The hand-over is recorded with both names. Nothing already saved is lost.
              </span>
            </p>
          ) : null}
        </div>
      ) : null}

      <form
        className="max-w-[80ch]"
        onSubmit={(e) => {
          e.preventDefault();
          setTouched(true);
          // A version saves with any field empty. Fields still to complete are
          // listed on the form and on the phase; the export prints a blank line.
          if (errorCount) {
            setMessage(
              `Saved with ${errorCount} field${errorCount === 1 ? "" : "s"} still to complete; the phase lists them before it can be exited.`,
            );
          }
          save.mutate();
        }}
      >

        <div id="doc-save-export" className="mc-work-toolbar mb-6 flex flex-wrap items-center">
          {canWrite ? (
          <Button
            type="submit"
            disabled={!canEdit || save.isPending}
          >
            {save.isPending ? "Saving" : "Save version"}
          </Button>
          ) : null}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button type="button" variant="outline">Export</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-44">
              <DropdownMenuItem
                onSelect={() => {
                  if (
                    (def.key === "postaward-letter-successful" ||
                      def.key === "postaward-letter-unsuccessful") &&
                    exportContext
                  ) {
                    // The notification letters are written into the NASA OP masters
                    // on a Part 15 file, and as the Part 12 or Part 13 companion
                    // notice on a commercial or simplified file.
                    const successful = def.key === "postaward-letter-successful";
                    const part15 = isPart15NotificationPath(exportContext);
                    if (!part15) {
                      const prefetched = companionDocxRef.current;
                      if (!prefetched || prefetched.key !== companionPrefetchKey) {
                        setMessage("The Word file did not export. Try again, or export PDF.");
                        return;
                      }
                      downloadDocxBytes(
                        prefetched.bytes,
                        `${successful ? "postaward-success" : "postaward-unsuccess"}-${acquisitionId}.docx`,
                      );
                      if (successful) {
                        setMessage(
                          `The successful-offeror companion notice was written under ${simplifiedNoticeCitation(exportContext)}.`,
                        );
                      } else {
                        setMessage(
                          `The unsuccessful-offeror companion notice was written with a brief explanation available on request (${unsuccessfulExplanationCitation(exportContext)}).`,
                        );
                      }
                      return;
                    }
                    const write = part15
                      ? successful
                        ? generatePostawardSuccessDocx(exportContext)
                        : generatePostawardUnsuccessDocx(exportContext)
                      : Promise.reject(new Error("The companion notice was not prefetched."));
                    void write
                      .then((bytes) => {
                        downloadDocxBytes(
                          bytes,
                          `${successful ? "postaward-success" : "postaward-unsuccess"}-${acquisitionId}.docx`,
                        );
                      })
                      .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                  } else if (def.key === "ppm" && exportContext) {

                    // The prenegotiation position is written into the NASA OP master.
                    if (!isPpmPath(exportContext)) {
                      setMessage(
                        "This file does not record an RFO FAR Part 15 non-competitive action, so the prenegotiation position memorandum was not written. A commercial or simplified file records price reasonableness under Part 12 and Part 13 instead.",
                      );
                    } else {
                      void generatePpmDocx(exportContext)
                        .then((bytes) => downloadDocxBytes(bytes, `ppm-${acquisitionId}.docx`))
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "setaside-preaward-notification" && exportContext) {
                    // The set-aside preaward notice is written into the NASA OP master.
                    if (!isSetAsidePreawardPath(exportContext)) {
                      setMessage(
                        "This file does not record an RFO FAR Part 15 negotiated set-aside, so the preaward notification was not written. Record the Part 15 path and the small business set-aside first; commercial and simplified files notify under Part 12 and Part 13 instead.",
                      );
                    } else {
                      void generateSetAsidePreawardDocx(exportContext)
                        .then((bytes) =>
                          downloadDocxBytes(bytes, `setaside-preaward-${acquisitionId}.docx`),
                        )
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "drfp-cover-letter" && exportContext) {
                    if (!isDrfpCoverPath(exportContext)) {
                      setMessage(
                        "This file is not on a competed RFO FAR Part 15 negotiated path, so the Draft RFP cover letter was not written.",
                      );
                    } else {
                      void generateDrfpCoverDocx(exportContext)
                        .then((bytes) => downloadDocxBytes(bytes, `drfp-cover-${acquisitionId}.docx`))
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "option-exercise-determination" && exportContext) {
                    // The determination is written into the NASA OP master.
                    if (!isOptionExercisePath(exportContext)) {
                      setMessage(
                        "This file does not record an awarded contract with an option to exercise, so the determination was not written. Record the contract number and the option first.",
                      );
                    } else {
                      void generateOptionExerciseDocx(exportContext)
                        .then((bytes) =>
                          downloadDocxBytes(bytes, `option-exercise-${acquisitionId}.docx`),
                        )
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "uca-letter-contract" && exportContext) {
                    // The letter contract justification is written into the NASA OP master.
                    if (!isUcaJustPath(exportContext)) {
                      setMessage(
                        "This file does not record an undefinitized action or a letter contract, so the justification was not written. Record the action first; commercial and simplified files do not use this face.",
                      );
                    } else {
                      void generateUcaJustDocx(exportContext)
                        .then((bytes) => downloadDocxBytes(bytes, `uca-just-${acquisitionId}.docx`))
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "blackout-notice") {
                    // The notice is written into the genuine HQ blackout master.
                    // Without the record in hand the method cannot be read, so
                    // the honest refusal stands rather than a generic document.
                    if (!exportContext || !isBlackoutPath(exportContext)) {
                      setMessage(BLACKOUT_UNAVAILABLE);
                    } else {
                      void generateBlackoutDocx(exportContext)
                        .then((bytes) => downloadDocxBytes(bytes, `blackout-${acquisitionId}.docx`))
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "fair-opportunity-brand-name" && exportContext) {
                    // The brand-name justification is written into the NASA OP master.
                    if (!isFoeBrandPath(exportContext)) {
                      setMessage(
                        "This file does not record an order placed under a multiple-award contract with a brand-name basis, so the justification was not written. Record the ordering vehicle and the brand-name item first; commercial and simplified files do not use this face.",
                      );
                    } else {
                      void generateFoeBrandDocx(exportContext)
                        .then((bytes) => downloadDocxBytes(bytes, `foe-brand-${acquisitionId}.docx`))
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "option-justification" && exportContext) {
                    // The option justification is written into the NASA OP master.
                    if (!isOptionJustificationPath(exportContext)) {
                      setMessage(
                        "This file is not on a negotiated or sealed bid solicitation path, so the option justification was not written. Commercial and simplified files do not use this memorandum.",
                      );
                    } else {
                      void generateOptionJustificationDocx(exportContext)
                        .then((bytes) =>
                          downloadDocxBytes(bytes, `option-justification-${acquisitionId}.docx`),
                        )
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (memoOn && memoDoc) void exportMemoDocx(memoDoc, `${def.key}-memo-${acquisitionId}`, exportHeaderLine);
                  else if (def.key === "jofoc-8a-over-30m" && exportContext) {
                    // The 8(a) justification is written into the NASA OP master.
                    if (!isJofoc8aPath(exportContext)) {
                      setMessage(
                        "This file does not record an 8(a) sole source action above $30 million, so the justification was not written. Record the 8(a) sole source path and the estimated value first.",
                      );
                    } else {
                      void generateJofoc8aDocx(exportContext)
                        .then((bytes) => downloadDocxBytes(bytes, `jofoc-8a-${acquisitionId}.docx`))
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "jofoc-urgency" && exportContext) {
                    // Urgency justification is written into the NASA OP urgency master.
                    if (!isUrgencyJofocPath(exportContext)) {
                      setMessage(
                        "This file does not record an unusual and compelling urgency authority, so the urgency justification was not written. Record the urgency authority first.",
                      );
                    } else {
                      void generateJofocUrgencyDocx(exportContext)
                        .then((bytes) => downloadDocxBytes(bytes, `jofoc-urgency-${acquisitionId}.docx`))
                        .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                    }
                  } else if (def.key === "jofoc" && exportContext) {
                    // The JOFOC is written into the NASA Word master, not built from scratch.
                    void generateJofocDocx(exportContext)
                      .then((bytes) => downloadDocxBytes(bytes, `jofoc-${acquisitionId}.docx`))
                      .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                  } else if (
                    (def.key === "limited-sources-justification" || def.key === "lsj") &&
                    exportContext
                  ) {
                    // The LSJ is written into the NASA OP Word master, not built from scratch.
                    void generateLsjDocx(exportContext)
                      .then((bytes) => downloadDocxBytes(bytes, `lsj-${acquisitionId}.docx`))
                      .catch(() => setMessage("The Word file did not export. Try again, or export PDF."));
                  } else if (exportRendered) void exportDocx(exportRendered, `${def.key}-${acquisitionId}`, exportContext, exportHeaderLine);
                }}
              >
                Export Word
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={() => {
                  if (memoOn && memoDoc) {
                    void exportMemoPdf(memoDoc, exportHeaderLine, `${def.key}-memo-${acquisitionId}`).catch(() =>
                      setMessage("The PDF did not export. Try again, or export Word."),
                    );
                    return;
                  }
                  if (exportRendered) void exportPdf(exportRendered, exportHeaderLine, `${def.key}-${acquisitionId}`, exportContext).catch(() =>
                    setMessage("The PDF did not export. Try again, or export Word."),
                  );
                }}
              >
                Export PDF
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {visibleSections(def, values).map((s) => {
          const body = (
            <>
            {sectionCite(s) ? (
              <p className="mb-2 text-[13px] text-muted-foreground">
                {sectionCite(s)}
                {s.tier ? ` · ${s.tier === "binding" ? "Binding" : "Guidance"}` : ""}
              </p>
            ) : null}
            {sectionBody(s) ? <p className="mb-3 text-[15px] leading-[22px]">{sectionBody(s)}</p> : null}
            {visibleFields(s, values).map((f) => {
              const id = `${s.id}-${f.key}`;
              const err = touched ? errors[f.key] : undefined;
              return (
                <div key={f.key} className="mb-4">
                  <div className="flex flex-wrap items-baseline gap-3">
                    <label htmlFor={id} className="block text-[13px] text-muted-foreground">
                      {f.label}
                      {f.required ? " (required)" : f.requiredAtExit ? " (required to exit the phase)" : ""}
                    </label>
                    <button
                      type="button"
                      className="text-[13px] text-primary underline"
                      onClick={() => openSource(s, f)}
                    >
                      Source
                    </button>
                    {def.key === "jofoc" && DRAFTABLE_JOFOC_FIELDS[f.key] && canEdit ? (
                      <button
                        type="button"
                        className="rounded-lg border border-border px-2 py-1 text-[13px]"
                        disabled={draftingKey === f.key}
                        onClick={() => void runDraft(f.key)}
                      >
                        {draftingKey === f.key ? "Drafting" : "Draft from the record"}
                      </button>
                    ) : null}
                  </div>
                   {aiMeta[f.key] ? (
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-[13px]">
                      <StatusMark color={aiMeta[f.key]!.reviewed ? "var(--ontrack)" : "var(--attention)"}>
                        {aiMeta[f.key]!.reviewed ? "Reviewed" : "Draft"}
                      </StatusMark>
                      <span className="text-muted-foreground">Drafted from the record; confirm it.</span>
                      <button type="button" className="text-primary underline-offset-2 hover:underline" onClick={() => openSource(s, f)}>
                        Details
                      </button>
                      {!aiMeta[f.key]!.reviewed && canEdit ? (
                        <button
                          type="button"
                          className="rounded-lg border border-border px-2 py-1 text-[13px]"
                          onClick={() => {
                            setTouched(true);
                            setAiMeta((prev) => ({ ...prev, [f.key]: { ...prev[f.key]!, reviewed: true } }));
                          }}
                        >
                          Mark reviewed
                        </button>
                      ) : null}
                    </div>
                  ) : draftedFields.has(f.key) ? (
                    <p className="mt-1 text-[13px] text-muted-foreground">Drafted from the record; confirm it.</p>
                  ) : null}
                  {f.kind === "readonly" ? (
                    <p id={id} className="text-[15px]">
                      {readonlyText(f)}
                    </p>
                  ) : f.kind === "textarea" ? (
                    <textarea
                      id={id}
                      rows={4}
                      className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                      value={values[f.key] ?? ""}
                      disabled={!canEdit}
                      onChange={(e) => set(f.key, e.target.value)}
                    />
                  ) : f.kind === "select" ? (
                    <select
                      id={id}
                      className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                      value={values[f.key] ?? ""}
                      disabled={!canEdit}
                      onChange={(e) => set(f.key, e.target.value)}
                    >
                      <option value="">Choose one</option>
                      {(f.key === "offeror_slot" && quoterSlots.length
                        ? quoterSlots.filter((r) => !r.awarded).map((r) => ({ value: r.slot, label: `${r.slot} — ${r.name}` }))
                        : // A value on the record that is not one of the offered
                          // choices is still shown, so the file keeps what it records.
                          [
                            ...(f.options ?? []),
                            ...((values[f.key] ?? "") && !(f.options ?? []).includes(values[f.key] ?? "")
                              ? [values[f.key] ?? ""]
                              : []),
                          ].map((o) => ({ value: o, label: o }))
                      ).map((o) => (
                        <option key={o.value} value={o.value}>
                          {o.label}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      id={id}
                      type={f.kind === "date" ? "date" : "text"}
                      inputMode={f.kind === "money" ? "decimal" : undefined}
                      className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                      value={values[f.key] ?? ""}
                      disabled={!canEdit}
                      onChange={(e) => set(f.key, e.target.value)}
                    />
                  )}
                  {f.help ? <p className="mt-1 text-[13px] text-muted-foreground">{f.help}</p> : null}
                  {f.helpFor?.(values) ? (
                    <p className="mt-1 text-[13px]" style={{ color: "var(--atrisk)" }}>
                      {f.helpFor(values)}
                    </p>
                  ) : null}
                  {err ? (
                    <p className="mt-1 text-[13px] text-atrisk">
                      Needs {f.label.toLowerCase()}
                    </p>
                  ) : null}
                </div>
              );
            })}
            </>
          );
          return (
            <section id={`doc-sec-${s.id}`} key={s.id} className="mc-work-form-section mb-8">
              {s.collapsed ? (
                <details>
                  <summary className="cursor-pointer text-[18px] leading-6 font-medium">{s.title}</summary>
                  <div className="mt-3">{body}</div>
                </details>
              ) : (
                <>
                  <h2 className="text-[18px] leading-6 font-medium">{s.title}</h2>
                  {body}
                </>
              )}
            </section>
          );
        })}


        {signature ? (
          <section id="doc-signatures" className="mc-work-form-section mb-8">
            <h2 className="text-[18px] leading-6 font-medium">Signatures</h2>
            <p className="text-[13px] text-muted-foreground">
              {signature.tierLabel} · {signature.citation} · selected by the estimated value{" "}
              <span data-numeric>{money(estimatedValue)}</span>
              {" "}· approving official:{" "}
              {approvingOfficialTitle(
                q.data?.routing?.approving_official_title,
                !(signature && signature.blocks.length > 2),
              )}
            </p>
            <ul className="mt-2">
              {signature.blocks.map((b) => (
                <li key={b} className="mb-1 text-[15px] leading-[22px]">
                  {b}
                </li>
              ))}
            </ul>
            {def.key === "jofoc" ? (
              <div className="mt-4 grid gap-6 sm:grid-cols-2">
                {[
                  {
                    role: "Technical Representative",
                    name: technicalRepresentative((q.data?.acq ?? {}) as Record<string, unknown>),
                  },
                  { role: "Contracting Officer", name: String(q.data?.acq?.["co_name"] ?? "") },
                ].map((p2) => (
                  <div key={p2.role}>
                    <div className="mt-6 border-t border-foreground pt-1 text-[13px] text-muted-foreground">
                      Signature
                    </div>
                    <p className="text-[15px] leading-[22px]">{p2.name || "Not recorded"}</p>
                    <p className="text-[13px] text-muted-foreground">{p2.role}</p>
                  </div>
                ))}
              </div>
            ) : null}
            {signature.note ? <p className="mt-2 text-[13px] text-muted-foreground">{signature.note}</p> : null}
          </section>
        ) : null}

        <section id="doc-nf1858" className="mc-work-form-section mb-8" aria-label="NF 1858 memorandum">
          <div className="flex flex-wrap items-center gap-3">
            <input
              id="issue-on-1858"
              type="checkbox"
              checked={!!memoOn}
              disabled={!canEdit}
              onChange={(e) => {
                setMemoOn(e.target.checked);
                setTouched(true);
              }}
            />
            <label htmlFor="issue-on-1858" className="text-[18px] leading-6 font-medium">
              Issue on NF 1858
            </label>
            <span className="text-[13px] text-muted-foreground">
              NASA Form 1858 (Rev 12/24) electronic letterhead memorandum.
            </span>
          </div>
          {memoOn && memoHeader ? (
            <div className="mt-4 max-w-[80ch]">
              <p className="mb-3 text-[13px] text-muted-foreground">
                {memoHeader.centerName}
                {memoHeader.centerAddress ? ` · ${memoHeader.centerAddress}` : ""} · {memoHeader.date} · Reply to Attn
                of: {memoHeader.replyTo || "Not recorded"}
              </p>
              <div className="mb-3">
                <label htmlFor="memo-to" className="text-[15px]">To</label>
                <input
                  id="memo-to"
                  className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                  value={memoHeader.to}
                  disabled={!canEdit}
                  onChange={(e) => { setMemo("to", e.target.value); setTouched(true); }}
                />
                <p className="mt-1 text-[13px] text-muted-foreground">
                  From the Center routing table for this document type. Edit it in Center configuration.
                </p>
              </div>
              <div className="mb-3">
                <label htmlFor="memo-thru" className="text-[15px]">Thru, one official per line</label>
                <textarea
                  id="memo-thru"
                  rows={2}
                  className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                  value={memoHeader.thru.join("\n")}
                  disabled={!canEdit}
                  onChange={(e) => { setMemo("thru", linesToList(e.target.value)); setTouched(true); }}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="memo-from" className="text-[15px]">From</label>
                <input
                  id="memo-from"
                  className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                  value={memoHeader.from}
                  disabled={!canEdit}
                  onChange={(e) => { setMemo("from", e.target.value); setTouched(true); }}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="memo-subject" className="text-[15px]">Subject</label>
                <input
                  id="memo-subject"
                  className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                  value={memoHeader.subject}
                  disabled={!canEdit}
                  onChange={(e) => { setMemo("subject", e.target.value); setTouched(true); }}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="memo-ref" className="text-[15px]">Ref, one authority per line</label>
                <textarea
                  id="memo-ref"
                  rows={2}
                  className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                  value={memoHeader.ref.join("\n")}
                  disabled={!canEdit}
                  onChange={(e) => { setMemo("ref", linesToList(e.target.value)); setTouched(true); }}
                />
              </div>
              <div className="mb-3 grid gap-3 sm:grid-cols-2">
                <div>
                  <label htmlFor="memo-sig-name" className="text-[15px]">Signature, typed name</label>
                  <input
                    id="memo-sig-name"
                    className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                    value={memoHeader.signatureName}
                    disabled={!canEdit}
                    onChange={(e) => { setMemo("signatureName", e.target.value); setTouched(true); }}
                  />
                </div>
                <div>
                  <label htmlFor="memo-sig-title" className="text-[15px]">Signature, title</label>
                  <input
                    id="memo-sig-title"
                    className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                    value={memoHeader.signatureTitle}
                    disabled={!canEdit}
                    onChange={(e) => { setMemo("signatureTitle", e.target.value); setTouched(true); }}
                  />
                </div>
              </div>
              <div className="mb-3">
                <label htmlFor="memo-conc" className="text-[15px]">Concurrence, one official per line as name, title</label>
                <textarea
                  id="memo-conc"
                  rows={3}
                  className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                  value={memoHeader.concurrence.map((c) => [c.name, c.title].filter(Boolean).join(", ")).join("\n")}
                  disabled={!canEdit}
                  onChange={(e) => {
                    setMemo(
                      "concurrence",
                      linesToList(e.target.value).map((l) => {
                        const [name, ...rest] = l.split(",");
                        return { name: rest.length ? (name ?? "").trim() : "", title: (rest.length ? rest.join(",") : l).trim() };
                      }),
                    );
                    setTouched(true);
                  }}
                />
                <p className="mt-1 text-[13px] text-muted-foreground">
                  Prefilled from the officials the Approvals step records, in order, and left blank for signature.
                </p>
              </div>
              <div className="mb-3">
                <label htmlFor="memo-encl" className="text-[15px]">Enclosures, one per line, numbered on the memo</label>
                <textarea
                  id="memo-encl"
                  rows={3}
                  className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                  value={memoHeader.enclosures.join("\n")}
                  disabled={!canEdit}
                  onChange={(e) => { setMemo("enclosures", linesToList(e.target.value)); setTouched(true); }}
                />
              </div>
              <div className="mb-3 grid gap-3 sm:grid-cols-2">
                <div>
                  <label htmlFor="memo-dist" className="text-[15px]">Distribution, one per line</label>
                  <textarea
                    id="memo-dist"
                    rows={2}
                    className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                    value={memoHeader.distribution.join("\n")}
                    disabled={!canEdit}
                    onChange={(e) => { setMemo("distribution", linesToList(e.target.value)); setTouched(true); }}
                  />
                </div>
                <div>
                  <label htmlFor="memo-cc" className="text-[15px]">cc, one per line</label>
                  <textarea
                    id="memo-cc"
                    rows={2}
                    className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
                    value={memoHeader.cc.join("\n")}
                    disabled={!canEdit}
                    onChange={(e) => { setMemo("cc", linesToList(e.target.value)); setTouched(true); }}
                  />
                </div>
              </div>
              <div className="flex items-center gap-3">
                <input
                  id="memo-cui"
                  type="checkbox"
                  checked={memoHeader.cui}
                  disabled={!canEdit}
                  onChange={(e) => { setMemo("cui", e.target.checked); setTouched(true); }}
                />
                <label htmlFor="memo-cui" className="text-[15px]">
                  Mark CUI, adding the banner and the cover sheet
                </label>
              </div>
            </div>
          ) : null}
        </section>



        {message ? (
          <p role="status" className="mb-6 text-[15px]">
            {message}
          </p>
        ) : null}
        {readOnly ? null : !canWrite ? (
          <p className="mb-6 text-[13px] text-muted-foreground">
            Reading only. Editing and saving require Contracting or HQ.
          </p>
        ) : null}
      </form>
      </>
      )}

      {def.key === "pnm" ? (
        <section id="doc-comparables" aria-label="Comparables lookup" className="mb-10 max-w-[80ch]">
          <h2 className="mb-1 text-[18px] leading-6 font-medium">Comparables lookup</h2>
          <p className="mb-3 text-[13px] text-muted-foreground">
            SAM.gov contract awards for this NAICS and PSC, half to double the estimated value.
          </p>
          <button
            type="button"
            className="rounded-lg border border-border px-3 py-2 text-[15px]"
            disabled={!canEdit || runComparables.isPending}
            onClick={() => runComparables.mutate()}
          >
            {runComparables.isPending ? "Running comparables" : "Run comparables"}
          </button>
          {comparables ? (
            <>
              <p className="mt-3 text-[13px]">
                <StatusMark color={comparables.source === "live" ? "var(--ontrack)" : "var(--attention)"}>
                  {comparables.sourceLabel}
                </StatusMark>
                <span className="ml-2 text-muted-foreground" data-numeric>
                  NAICS {comparables.naicsCode} · PSC {comparables.pscCode} · {money(comparables.minValue)} to{" "}
                  {money(comparables.maxValue)}
                </span>
              </p>
              {comparables.source !== "live" && comparables.providerNote ? (
                <p className="mt-1 text-[13px] text-muted-foreground">{comparables.providerNote}</p>
              ) : null}
              {comparables.awards.length ? (
                <TableScrollRegion baseClassName="overflow-x-auto" label="Comparable awards table">
                <table className="mt-3 w-full border border-border bg-background text-[13px] leading-[18px]">
                  <thead>
                    <tr className="border-b border-border text-left">
                      <th scope="col" className="px-3 py-2 font-medium">Agency</th>
                      <th scope="col" className="px-3 py-2 font-medium">Award date</th>
                      <th scope="col" className="px-3 py-2 font-medium">Pricing type</th>
                      <th scope="col" className="px-3 py-2 font-medium">Extent competed</th>
                      <th scope="col" className="px-3 py-2 font-medium">Obligated</th>
                    </tr>
                  </thead>
                  <tbody>
                    {comparables.awards.map((a, i) => (
                      <tr key={`${a.agency}-${a.awardDate}-${i}`} className="border-b border-border last:border-0 align-top">
                        <td className="px-3 py-2">{a.agency}</td>
                        <td className="px-3 py-2" data-numeric>{a.awardDate}</td>
                        <td className="px-3 py-2">{a.pricingType}</td>
                        <td className="px-3 py-2">{a.extentCompeted}</td>
                        <td className="px-3 py-2" data-numeric>{money(a.obligatedAmount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                </TableScrollRegion>
              ) : (
                <p className="mt-3 text-muted-foreground">No prior awards came back for this NAICS and PSC.</p>
              )}
              <p className="mt-2 text-[13px] text-muted-foreground">
                The summary above the table is written into the memorandum. Edit it to state what the comparison shows.
              </p>
            </>
          ) : (
            <p className="mt-3 text-muted-foreground">
              No comparables run yet. Run comparables to pull prior awards for this requirement.
            </p>
          )}
        </section>
      ) : null}


      <MissionNavSection id="doc-provenance" label="Provenance" collapsible summary="Source and review details">
      <section aria-label="Provenance" className="max-w-[80ch]">
        <div className="flex flex-wrap items-center gap-2 text-[13px]">
          <span className="rounded-full border border-border bg-background px-2.5 py-1 font-medium">Live</span>
          {isSampleFile ? <span className="rounded-full border border-border bg-background px-2.5 py-1 font-medium">Sample</span> : null}
          {hasUnreviewedDraft || (latest && !latest.reviewed_by) ? (
            <span className="rounded-full border border-border bg-background px-2.5 py-1 font-medium">Draft</span>
          ) : null}
          {latest?.reviewed_by ? <span className="rounded-full border border-border bg-background px-2.5 py-1 font-medium">Reviewed</span> : null}
          {latest && isOfficialFinal(latest.field_values) ? (
            <span className="rounded-full border border-border bg-background px-2.5 py-1 font-medium">Official</span>
          ) : null}
          <details className="ml-1">
            <summary className="cursor-pointer text-primary">Details</summary>
            <div className="mt-3 max-w-[70ch] text-muted-foreground">
              {latest ? (
                <>
                  <p>Saved from the live acquisition record.</p>
                  <p className="mt-1">
                    Model: {latest.ai_model ?? "Not recorded"} · Generated:{" "}
                    {latest.ai_generated_at ? new Date(latest.ai_generated_at).toLocaleString() : "Not recorded"}
                  </p>
                  <p className="mt-1">
                    Reviewed by: {latest.reviewed_by ?? "Not recorded"} · Reviewed at:{" "}
                    {latest.reviewed_at ? new Date(latest.reviewed_at).toLocaleString() : "Not recorded"}
                  </p>
                  {canWrite && !latest.reviewed_by ? (
                    <Button type="button" variant="outline" size="sm" className="mt-3" onClick={() => markReviewed.mutate()} disabled={markReviewed.isPending}>
                      Mark reviewed
                    </Button>
                  ) : null}
                </>
              ) : (
                <p>Save a version to record full provenance details.</p>
              )}
            </div>
          </details>
        </div>
      </section>
      </MissionNavSection>

      <section id="doc-official-copy" aria-label="Official file copy" className="mb-10 max-w-[80ch] rounded-xl border border-border bg-background p-5">
        <div className="flex flex-wrap items-center gap-2">
          <h2 className="text-[18px] leading-6 font-medium">Official file copy</h2>
          <AdvisoryTag text="Advisory. Filing a version never holds the file or blocks a phase exit." />
        </div>

        <h3 className="mt-4 text-[15px] leading-[22px] font-medium">Route</h3>
        {memoHeader?.to || q.data?.routing ? (
          <dl className="mt-1 text-[13px] leading-[18px]">
            <div className="flex gap-2">
              <dt className="text-muted-foreground">To</dt>
              <dd>{memoHeader?.to || q.data?.routing?.approving_official_title || "Not recorded"}</dd>
            </div>
            {(() => {
              const thruList = (memoHeader?.thru?.length ? memoHeader.thru : (q.data?.routing?.thru_chain ?? [])).filter(Boolean);
              return thruList.length > 0 ? (
                <div className="flex gap-2">
                  <dt className="text-muted-foreground">Thru</dt>
                  <dd>{thruList.join(" · ")}</dd>
                </div>
              ) : null;
            })()}
            <div className="flex gap-2">
              <dt className="text-muted-foreground">From</dt>
              <dd>{memoHeader?.from || "Not recorded"}</dd>
            </div>
          </dl>
        ) : (
          <p className="mt-1 text-[13px] leading-[18px] text-muted-foreground">
            No routing recorded for this document type at this Center.
          </p>
        )}

        <h3 className="mt-4 text-[15px] leading-[22px] font-medium">Concurrence and approval</h3>
        {latest ? (
          (() => {
            const meta = officialMeta(latest.field_values);
            const outstanding = board.filter((b) => !b.vote || /pending/i.test(String(b.vote))).length;
            return (
              <>
                <p className="mt-1 text-[13px] leading-[18px] text-muted-foreground">
                  Reviewed by {latest.reviewed_by ?? "no one yet"}
                  {latest.reviewed_at ? ` on ${String(latest.reviewed_at).slice(0, 10)}` : ""}.{" "}
                  {board.length
                    ? `${board.length - outstanding} of ${board.length} reviewers have recorded a vote for ${phase}. Votes are shown below.`
                    : "No review poll is open for this phase."}
                </p>
                {canWrite && !latest.reviewed_by ? (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => markReviewed.mutate()}
                    disabled={markReviewed.isPending}
                  >
                    Record concurrence
                  </Button>
                ) : null}

                <h3 className="mt-4 text-[15px] leading-[22px] font-medium">File it</h3>
                <p className="mt-1 text-[15px] leading-[22px]">
                  {meta.official
                    ? `Official final · filed ${meta.filedAt ? meta.filedAt.slice(0, 10) : "date not recorded"}${
                        meta.filedBy ? ` by ${meta.filedBy}` : ""
                      } — version ${latest.version}.`
                    : `Version ${latest.version} is a draft. No official final is filed for this document yet.`}
                </p>
                <p className="mt-1 text-[13px] leading-[18px] text-muted-foreground">{FILE_IT_NOTE}</p>
                {canWrite ? (
                  meta.official ? (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="mt-3"
                      onClick={() => unfileOfficial.mutate()}
                      disabled={unfileOfficial.isPending}
                    >
                      Unfile
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="mt-3"
                      onClick={() => fileOfficial.mutate()}
                      disabled={fileOfficial.isPending}
                    >
                      {FILE_IT_LABEL}
                    </Button>
                  )
                ) : null}
              </>
            );
          })()
        ) : (
          <p className="mt-2 text-[15px] leading-[22px] text-muted-foreground">
            Save a version first. The contracting officer can then file one version as the official copy.
          </p>
        )}
      </section>

      <section id="doc-poll" aria-label="Reviews and approvals" className="mb-10 max-w-[80ch]">
        <h2 className="mb-3 text-[18px] leading-6 font-medium">Reviews and approvals for {phase}</h2>
        {board.length ? (
          <TableScrollRegion baseClassName="overflow-x-auto" label={`Reviews and approvals for ${acquisitionId}`}>
          <table className="w-full border border-border bg-background text-[13px] leading-[18px]">
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="px-3 py-2 font-medium">Reviewer</th>
                <th scope="col" className="px-3 py-2 font-medium">Name</th>
                <th scope="col" className="px-3 py-2 font-medium">Decision</th>
                <th scope="col" className="px-3 py-2 font-medium">Due</th>
              </tr>
            </thead>
            <tbody>
              {board.map((b) => (
                <tr key={`${b.phase}-${b.reviewer_role}`} className="border-b border-border last:border-0 align-top">
                  <td className="px-3 py-2">
                    {b.reviewer_role}
                    <span className="block text-[12px] text-muted-foreground">{REVIEW_KIND_LABEL[b.kind]}</span>
                  </td>
                  <td className="px-3 py-2">{b.reviewer_name}</td>
                  <td className="px-3 py-2">
                    <StatusMark
                      color={
                        b.vote === "favorable"
                          ? "var(--ontrack)"
                          : b.vote === "unfavorable"
                            ? "var(--atrisk)"
                            : "var(--attention)"
                      }
                    >
                      {b.decision ? DECISION_LABEL[b.decision] : "Pending"}
                      {b.reason ? `: ${b.reason}` : ""}
                    </StatusMark>
                  </td>

                  <td className="px-3 py-2" data-numeric>
                    {b.due_date ?? "Not recorded"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </TableScrollRegion>
        ) : (
          <p className="text-muted-foreground">No review is triggered for this phase.</p>
        )}

        {hasRole("reviewer") && !readOnly ? (
          mySeat?.poll_id ? (
            <div className="mt-4 space-y-3">
              <ReviewDecisionFields
                idPrefix="doc-vote"
                options={decisionOptions(mySeat.kind, mySeat.decision)}
                decision={voteDecision}
                onDecision={setVoteDecision}
                rationale={voteReason}
                onRationale={setVoteReason}
                kindLabel={REVIEW_KIND_LABEL[mySeat.kind]}
                disabled={vote.isPending}
              />
              <button
                type="button"
                className="rounded-lg border-2 bg-background px-3 py-2 text-[15px] text-foreground"
                style={{ borderColor: decisionOutcome(voteDecision) === "unfavorable" ? "var(--atrisk)" : "var(--ontrack)" }}
                disabled={vote.isPending || !voteDecision}
                onClick={() => {
                  if (!voteDecision) return;
                  if (rationaleMissing(voteDecision, voteReason)) {
                    setMessage(`${DECISION_LABEL[voteDecision]} needs a written rationale. Write one, then record the decision.`);
                    return;
                  }
                  vote.mutate({ choice: voteDecision, reason: voteReason.trim() || null });
                }}
              >
                {voteDecision ? `Record ${DECISION_LABEL[voteDecision]}` : "Record decision"}
              </button>
            </div>
          ) : (
            <p className="mt-3 text-[13px] text-muted-foreground">
              The review request for this phase is not open yet. A contracting specialist sends it from the acquisition file.
            </p>
          )
        ) : null}
      </section>

      <section id="doc-comments" aria-label="Comments" className="mb-10 max-w-[80ch]">
        <h2 className="mb-3 text-[18px] leading-6 font-medium">Comments</h2>
        {q.data?.comments.length ? (
          <ul className="mb-4 border border-border bg-background">
            {q.data.comments.map((c) => (
              <li key={c.comment_id} className="border-b border-border p-3 last:border-0">
                <p className="text-[13px] text-muted-foreground">
                  {c.author ?? "Author not recorded"} · {new Date(c.created_at).toLocaleString()}
                </p>
                <p className="text-[15px] leading-[22px]">{c.body}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p className="mb-4 text-muted-foreground">No comments yet. Start the thread below.</p>
        )}
        {canWrite ? (<>
        <label htmlFor="new-comment" className="block text-[13px] text-muted-foreground">
          Add a comment
        </label>
        <textarea
          id="new-comment"
          rows={3}
          className="mt-1 w-full rounded-lg border border-border bg-background p-2 text-[15px]"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />
        <button
          type="button"
          className="mt-3 rounded-lg border border-border px-3 py-2 text-[15px]"
          disabled={addComment.isPending || !comment.trim() || !latest}
          onClick={() => addComment.mutate(comment.trim())}
        >
          Add comment
        </button>
        {!latest ? (
          <p className="mt-2 text-[13px] text-muted-foreground">Save a version first, then comment on it.</p>
        ) : null}
        </>) : readOnly ? null : (
          <p className="text-[13px] text-muted-foreground">
            Reading only. Editing and saving require Contracting or HQ.
          </p>
        )}
      </section>

      {readOnly ? null : (
        <ShareDocument
          documentId={latest?.document_id ?? null}
          canShare={hasAnyRole(["specialist", "hq"])}
        />
      )}

      <MissionNavSection id="doc-versions" label="Versions" collapsible summary={`${q.data?.versions.length ?? 0} saved`}>
      <section className="max-w-[80ch]">
        <h2 className="mb-3 text-[18px] leading-6 font-medium">Versions</h2>
        {q.data?.versions.length ? (
          <TableScrollRegion baseClassName="overflow-x-auto" label="Versions table">
          <table className="w-full border border-border bg-background text-[13px] leading-[18px]">
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="px-3 py-2 font-medium">Version</th>
                <th scope="col" className="px-3 py-2 font-medium">Saved by</th>
                <th scope="col" className="px-3 py-2 font-medium">Saved</th>
              </tr>
            </thead>
            <tbody>
              {q.data.versions.map((v) => (
                <tr key={v.document_id} className="border-b border-border last:border-0">
                  <td className="px-3 py-2" data-numeric>
                    {v.version}
                  </td>
                  <td className="px-3 py-2">{v.saved_by ?? "Not recorded"}</td>
                  <td className="px-3 py-2">{v.saved_at ? new Date(v.saved_at).toLocaleString() : "Not recorded"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          </TableScrollRegion>
        ) : (
          <p className="text-muted-foreground">No versions yet. Save one to start the history.</p>
        )}
      </section>
      </MissionNavSection>

      <MissionNavSection id="doc-regulations" label="Regulations">
        <RegulationSidebar phase={(phaseAlias(q.data?.acq?.["current_phase"] as string | null) as string | null) || phase} />
      </MissionNavSection>
      <MissionNavSection id="doc-defect" label="Report a defect" collapsible summary="Support details">
        <DefectReport
          templateKey={templateKey}
          templateName={def.name}
          revision={def.badge.revision}
          defaultCitation={badgeCite}
          acquisitionId={acquisitionId}
        />
      </MissionNavSection>

      {sourcePanel ? (
        <section
          aria-label="Source"
          className="mb-10 max-w-[80ch] border border-border bg-background p-4"
        >
          <h2 className="text-[18px] leading-6 font-medium">Source of {sourcePanel.title}</h2>
          <ul className="mt-2 space-y-1">
            {sourcePanel.lines.map((line) => (
              <li key={line} className="text-[15px] leading-[22px]">
                {line}
              </li>
            ))}
          </ul>
          <button
            type="button"
            className="mt-3 rounded-lg border border-border px-3 py-2 text-[15px]"
            onClick={() => setSourcePanel(null)}
          >
            Close
          </button>
        </section>
      ) : null}

      <div className="flex gap-4">
        <Link to="/templates" className="text-primary">
          Back to Templates
        </Link>
        <Link to="/files/$acquisitionId" params={{ acquisitionId }} className="text-primary">
          Open the acquisition file
        </Link>
      </div>
      </WithDetailsPanel>
      </WorkShellLayout>
    </AppShell>
  );
}
